@echo off
cd /d "%~dp0"
title Hive Dev - Start

cls
echo ==========================================
echo         HIVE DEV - START SCRIPT
echo ==========================================
echo.

:: Verifica Node.js
node -v >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Node.js nao encontrado!
    echo Instale em: https://nodejs.org
    pause
    exit /b 1
)

echo [OK] Node.js detectado
echo.

:: Instala dependencias se necessario
if not exist "node_modules" (
    echo [*] Instalando dependencias...
    call npm install
    if errorlevel 1 (
        echo [ERRO] Falha na instalacao!
        pause
        exit /b 1
    )
    echo [OK] Dependencias instaladas!
) else (
    echo [OK] Dependencias ok
)

echo [*] Verificando dependencias do servidor...
if not exist "node_modules\express" (
    echo [*] Instalando Express...
    call npm install express
    if errorlevel 1 (
        echo [ERRO] Falha ao instalar Express!
        pause
        exit /b 1
    )
    echo [OK] Express instalado!
)

echo.
echo [*] Iniciando servidor PROTEGIDO...
echo [*] URL: http://localhost:3000
echo [*] CTRL+C para parar
echo [*] URL copiada para a area de transferencia!
echo http://localhost:3000 | clip
echo ==========================================
echo.

node server.js

echo.
echo [*] Servidor parado.
pause
