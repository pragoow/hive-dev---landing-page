/**
 * Hive Dev - Protected Server
 * Serves static files with backend verification
 */

const express = require('express');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

// Generate daily token (changes every day)
const DAILY_TOKEN = crypto.createHash('sha256')
  .update(new Date().toISOString().split('T')[0] + '-hive-dev-secret')
  .digest('hex')
  .substring(0, 32);

// API endpoint for client verification
app.get('/api/ping', (req, res) => {
  const clientSource = req.headers['x-source'];
  
  // Only respond to valid clients
  if (clientSource !== 'hive-dev-client') {
    return res.status(403).json({ 
      status: 'error', 
      verified: false,
      message: 'Invalid client'
    });
  }
  
  res.json({
    status: 'ok',
    verified: true,
    token: DAILY_TOKEN,
    timestamp: Date.now()
  });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    version: '1.0.0',
    protected: true 
  });
});

// Serve static files
app.use(express.static('.', {
  dotfiles: 'deny',
  index: ['index.html'],
  maxAge: 0,
  setHeaders: (res, path) => {
    const normalized = path.replace(/\\/g, '/');

    // Allow caching for public assets (favicons/logos/images) to prevent favicon flicker
    const isPublicAsset = normalized.includes('/public/assets/');
    const isImage = /\.(png|ico|svg|jpg|jpeg|webp)$/i.test(normalized);

    if (isPublicAsset && isImage) {
      res.set('Cache-Control', 'public, max-age=31536000, immutable');
      return;
    }

    // Prevent caching for all other files
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    res.set('Surrogate-Control', 'no-store');
  }
}));

// Handle clean URLs for portfolio projects (without .html extension)
app.get('/public/pages/portfolio/:category/:id', (req, res) => {
  const { category, id } = req.params;
  const filePath = path.join(__dirname, 'public/pages/portfolio', category, `${id}.html`);
  
  res.sendFile(filePath, (err) => {
    if (err) {
      // If file not found, serve 404
      res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
    }
  });
});

// Handle clean URLs for portfolio projects (NEW SHORT URLs)
app.get('/portfolio/:category/:id', (req, res) => {
  const { category, id } = req.params;
  const filePath = path.join(__dirname, 'public/pages/portfolio', category, `${id}.html`);
  
  res.sendFile(filePath, (err) => {
    if (err) {
      // If file not found, serve 404
      res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
    }
  });
});

// Handle clean URLs for other pages (without .html extension)
app.get('/public/pages/:page', (req, res) => {
  const { page } = req.params;
  const filePath = path.join(__dirname, 'public/pages', `${page}.html`);
  
  res.sendFile(filePath, (err) => {
    if (err) {
      // If file not found, serve 404
      res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
    }
  });
});

// Handle clean URLs for other pages (NEW SHORT URLs)
app.get('/:page', (req, res) => {
  const { page } = req.params;
  
  // Skip if it's an API route or static asset
  if (page.startsWith('api/') || page.startsWith('public/') || page.includes('.')) {
    return res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
  }
  
  const filePath = path.join(__dirname, 'public/pages', page, 'index.html');
  
  res.sendFile(filePath, (err) => {
    if (err) {
      // If file not found, serve 404
      res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
    }
  });
});

// Handle clean URLs for portfolio categories (without .html extension)
app.get('/public/pages/portfolio/:category', (req, res) => {
  const { category } = req.params;
  const filePath = path.join(__dirname, 'public/pages/portfolio', category, 'index.html');
  
  res.sendFile(filePath, (err) => {
    if (err) {
      // If file not found, serve 404
      res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
    }
  });
});

// Handle clean URLs for portfolio categories (NEW SHORT URLs)
app.get('/portfolio/:category', (req, res) => {
  const { category } = req.params;
  const filePath = path.join(__dirname, 'public/pages/portfolio', category, 'index.html');
  
  res.sendFile(filePath, (err) => {
    if (err) {
      // If file not found, serve 404
      res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
    }
  });
});

// Handle 404
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'public/pages/404.html'));
});

// Export for Vercel
module.exports = app;

app.listen(PORT, () => {
  console.log(`\n🚀 Hive Dev Server running on http://localhost:${PORT}`);
  console.log(`🔒 Backend verification: ENABLED`);
  console.log(`📁 Static files serving from: ${__dirname}`);
  console.log(`\nPress CTRL+C to stop\n`);
});
