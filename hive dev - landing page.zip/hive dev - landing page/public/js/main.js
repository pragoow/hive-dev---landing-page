/**
 * Hive Dev - Main JavaScript
 * Animações, interatividade e utilitários
 */

// ==========================================
// Scroll Animations
// ==========================================
const ScrollAnimations = {
  init() {
    const observerOptions = {
      root: null,
      rootMargin: '0px 0px -50px 0px',
      threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    // Animate elements
    const animateElements = document.querySelectorAll('.animate');
    animateElements.forEach(el => observer.observe(el));
  }
};

// ==========================================
// Navbar
// ==========================================
const Navbar = {
  init() {
    const navbar = document.querySelector('.navbar');
    const menuToggle = document.querySelector('.menu-toggle');
    const navbarNav = document.querySelector('.navbar-nav');

    if (!navbar) return;

    // Scroll effect
    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });

    // Mobile menu toggle
    if (menuToggle && navbarNav) {
      menuToggle.addEventListener('click', () => {
        navbarNav.classList.toggle('active');
        const icon = menuToggle.querySelector('i');
        if (icon) {
          icon.className = navbarNav.classList.contains('active') 
            ? 'fas fa-times' 
            : 'fas fa-bars';
        }
      });

      // Close menu on link click
      navbarNav.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
          navbarNav.classList.remove('active');
          const icon = menuToggle.querySelector('i');
          if (icon) icon.className = 'fas fa-bars';
        });
      });
    }
  }
};

// ==========================================
// Smooth Scroll
// ==========================================
const SmoothScroll = {
  init() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e) => {
        const href = anchor.getAttribute('href');
        if (href === '#') return;

        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          const navbarHeight = document.querySelector('.navbar')?.offsetHeight || 0;
          const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navbarHeight;

          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      });
    });
  }
};

// ==========================================
// Form Validation
// ==========================================
const FormValidation = {
  init() {
    const forms = document.querySelectorAll('form[data-validate]');
    
    forms.forEach(form => {
      form.addEventListener('submit', (e) => this.handleSubmit(e, form));
    });
  },

  handleSubmit(e, form) {
    e.preventDefault();
    let isValid = true;

    // Clear previous errors
    form.querySelectorAll('.error-message').forEach(el => el.remove());
    form.querySelectorAll('.form-group').forEach(el => el.classList.remove('error'));

    // Validate required fields
    const requiredInputs = form.querySelectorAll('[required]');
    requiredInputs.forEach(input => {
      if (!input.value.trim()) {
        isValid = false;
        this.showError(input, 'Este campo é obrigatório');
      }
    });

    // Validate email
    const emailInput = form.querySelector('input[type="email"]');
    if (emailInput && emailInput.value) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailInput.value)) {
        isValid = false;
        this.showError(emailInput, 'Email inválido');
      }
    }

    if (isValid) {
      this.showSuccess(form);
    }
  },

  showError(input, message) {
    const formGroup = input.closest('.form-group');
    if (!formGroup) return;

    formGroup.classList.add('error');
    
    const errorEl = document.createElement('span');
    errorEl.className = 'error-message';
    errorEl.style.cssText = 'color: #ef4444; font-size: 0.875rem; margin-top: 0.25rem; display: block;';
    errorEl.textContent = message;
    
    formGroup.appendChild(errorEl);
    input.style.borderColor = '#ef4444';
  },

  showSuccess(form) {
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn?.innerHTML;

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
    }

    setTimeout(() => {
      alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
      form.reset();
      
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    }, 1500);
  }
};

// ==========================================
// Portfolio Filter
// ==========================================
const PortfolioFilter = {
  init() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const portfolioCards = document.querySelectorAll('[data-category]');

    if (!filterBtns.length || !portfolioCards.length) return;

    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        // Update active state
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const filter = btn.getAttribute('data-filter');

        // Filter cards
        portfolioCards.forEach(card => {
          const category = card.getAttribute('data-category');
          
          if (filter === 'all' || category === filter) {
            card.style.display = 'block';
            card.style.animation = 'fadeInUp 0.5s ease forwards';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }
};

// ==========================================
// Counter Animation
// ==========================================
const CounterAnimation = {
  init() {
    const counters = document.querySelectorAll('.stat-value[data-count]');
    
    if (!counters.length) return;

    const observerOptions = {
      threshold: 0.5
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.animate(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    counters.forEach(counter => observer.observe(counter));
  },

  animate(counter) {
    const target = parseInt(counter.getAttribute('data-count'));
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const update = () => {
      current += step;
      if (current < target) {
        counter.textContent = Math.floor(current) + '+';
        requestAnimationFrame(update);
      } else {
        counter.textContent = target + '+';
      }
    };

    update();
  }
};

// ==========================================
// Parallax Effect
// ==========================================
const ParallaxEffect = {
  init() {
    const parallaxElements = document.querySelectorAll('.hero-glow');
    
    if (!parallaxElements.length || window.matchMedia('(pointer: coarse)').matches) return;

    window.addEventListener('scroll', () => {
      const scrolled = window.pageYOffset;
      
      parallaxElements.forEach(el => {
        const speed = 0.3;
        el.style.transform = `translateY(${scrolled * speed}px)`;
      });
    });
  }
};

// ==========================================
// Initialize
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
  ScrollAnimations.init();
  Navbar.init();
  SmoothScroll.init();
  FormValidation.init();
  PortfolioFilter.init();
  CounterAnimation.init();
  ParallaxEffect.init();
});

// Re-initialize after page transitions (if using PJAX)
window.addEventListener('pageready', () => {
  ScrollAnimations.init();
  Navbar.init();
  PortfolioFilter.init();
  CounterAnimation.init();
});
