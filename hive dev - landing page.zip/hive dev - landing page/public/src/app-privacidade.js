/**
 * HIVE DEV - POLÍTICA DE PRIVACIDADE
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  app.innerHTML = `
    ${renderNavbar('privacidade')}

    <section class="hero" style="min-height: auto; padding: 140px 24px 60px;">
      <div class="hero-content">
        <span class="section-label">Legal</span>
        <h1 style="font-size: clamp(2rem, 5vw, 3.5rem);">
          Política de <span style="color: var(--accent);">Privacidade</span>
        </h1>
        <p style="margin-bottom: 0;">Última atualização: 19 de Março de 2026</p>
      </div>
    </section>

    <section class="section" style="padding-top: 0; max-width: 800px; margin: 0 auto;">
      <div class="card" style="text-align: left;">
        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">1. Informações que Coletamos</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          A Hive Dev coleta apenas as informações necessárias para prestar nossos serviços:
        </p>
        <ul style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px; padding-left: 20px;">
          <li>Nome e informações de contato (email, Discord)</li>
          <li>Detalhes sobre o projeto solicitado</li>
          <li>Informações de pagamento (processadas por terceiros)</li>
          <li>Dados técnicos necessários para desenvolvimento (acessos, APIs)</li>
        </ul>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">2. Como Usamos suas Informações</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          Utilizamos suas informações exclusivamente para:
        </p>
        <ul style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px; padding-left: 20px;">
          <li>Desenvolver e entregar o projeto contratado</li>
          <li>Comunicar-nos sobre o andamento do projeto</li>
          <li>Processar pagamentos</li>
          <li>Fornecer suporte pós-entrega</li>
        </ul>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">3. Proteção de Dados</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          Implementamos medidas de segurança técnicas e organizacionais para proteger suas informações contra acesso não autorizado, alteração, divulgação ou destruição não autorizada.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">4. Compartilhamento de Informações</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          Não vendemos, trocamos ou transferimos suas informações pessoais para terceiros. Isso não inclui prestadores de serviço confiáveis que nos auxiliam na operação do site ou condução do negócio, desde que concordem em manter estas informações confidenciais.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">5. Cookies e Tecnologias Semelhantes</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          Nosso site utiliza cookies apenas para armazenar preferências de tema (claro/escuro) e melhorar a experiência do usuário. Não utilizamos cookies de rastreamento ou publicidade.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">6. Seus Direitos</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          Você tem o direito de:
        </p>
        <ul style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px; padding-left: 20px;">
          <li>Acessar seus dados pessoais</li>
          <li>Solicitar correção de dados incorretos</li>
          <li>Solicitar exclusão de seus dados</li>
          <li>Revogar consentimento a qualquer momento</li>
        </ul>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">7. Retenção de Dados</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          Mantemos suas informações apenas pelo tempo necessário para cumprir as finalidades descritas nesta política, ou conforme exigido por lei. Após o término do contrato, dados pessoais são mantidos por até 1 ano para fins de suporte, a menos que solicite a exclusão.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">8. Alterações nesta Política</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          Podemos atualizar esta política periodicamente. A data da última atualização será sempre indicada no topo da página. Recomendamos revisar esta política regularmente.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">9. Contato</h3>
        <p style="color: var(--text-sec); line-height: 1.8;">
          Para exercer seus direitos ou esclarecer dúvidas sobre privacidade, entre em contato pelo Discord ou Instagram listados no rodapé do site.
        </p>
      </div>
    </section>

    ${renderFooter(false)}
  `;
})();
