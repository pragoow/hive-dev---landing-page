/**
 * HIVE DEV - PORTFOLIO CATEGORIA
 * Listagem de projetos por categoria com paginação
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  // Detecta categoria pela URL
  const path = window.location.pathname;
  const categoriaMatch = path.match(/\/portfolio\/(botsdiscord|sites|automacoes)(\/|$)/);
  const isCategoryPage = Boolean(categoriaMatch);
  const categoryBase = isCategoryPage ? '../' : '';
  const todosHref = '/portfolio/';
  const categoria = path.includes('botsdiscord') ? 'botsdiscord' : 
                    path.includes('sites') ? 'sites' : 
                    path.includes('automacoes') ? 'automacoes' : 'todos';

  // Paginação - obtém página atual da URL
  const urlParams = new URLSearchParams(window.location.search);
  const paginaAtual = parseInt(urlParams.get('page')) || 1;
  const projetosPorPagina = 4;

  const categorias = {
    botsdiscord: { nome: 'Bots Discord', icon: 'fab fa-discord', color: '#5865F2' },
    sites: { nome: 'Sites & Web', icon: 'fas fa-globe', color: '#3b82f6' },
    automacoes: { nome: 'Automações', icon: 'fas fa-robot', color: '#10b981' }
  };

  const current = categorias[categoria] || { nome: 'Portfólio', icon: 'fas fa-folder', color: 'var(--accent)' };

  // Projetos por categoria
  const projetos = {
    botsdiscord: [
      {
        id: 1,
        cat: 'botsdiscord',
        title: 'Moderação Pro',
        subtitle: 'Bot Discord Premium',
        icon: 'fab fa-discord',
        gradient: 'linear-gradient(135deg, #5865F2, #4752C4)',
        tags: ['Discord.js', 'Node.js', 'MongoDB'],
        desc: 'Sistema completo de moderação com auto-moderação, níveis, economia e dashboard web.'
      },
      {
        id: 2,
        cat: 'botsdiscord',
        title: 'Bot de Música',
        subtitle: 'Discord Music Bot',
        icon: 'fas fa-music',
        gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
        tags: ['Discord.js', 'Lavalink', 'Spotify API'],
        desc: 'Reprodução de alta qualidade com suporte a Spotify, YouTube, playlists e filtros de áudio.'
      },
      {
        id: 3,
        cat: 'botsdiscord',
        title: 'Sistema de Level',
        subtitle: 'Gamificação Discord',
        icon: 'fas fa-trophy',
        gradient: 'linear-gradient(135deg, #ec4899, #db2777)',
        tags: ['Discord.js', 'Redis', 'Canvas'],
        desc: 'Sistema de níveis com cards de perfil, rankings e recompensas automáticas.'
      },
      {
        id: 4,
        cat: 'botsdiscord',
        title: 'Sistema de Tickets',
        subtitle: 'Suporte Discord',
        icon: 'fas fa-ticket-alt',
        gradient: 'linear-gradient(135deg, #06b6d4, #0891b2)',
        tags: ['Discord.js', 'TypeScript', 'MongoDB'],
        desc: 'Sistema avançado de tickets com múltiplas categorias e transcrição automática.'
      },
      {
        id: 5,
        cat: 'botsdiscord',
        title: 'Bot de Economia',
        subtitle: 'Economia Virtual Discord',
        icon: 'fas fa-coins',
        gradient: 'linear-gradient(135deg, #fbbf24, #f59e0b)',
        tags: ['Discord.js', 'MongoDB', 'Canvas'],
        desc: 'Economia virtual completa com loja, inventário, cassino e trabalhos.'
      }
    ],
    sites: [
      {
        id: 1,
        cat: 'sites',
        title: 'Loja Virtual',
        subtitle: 'E-commerce Completo',
        icon: 'fas fa-shopping-bag',
        gradient: 'linear-gradient(135deg, #3b82f6, #2563eb)',
        tags: ['Next.js', 'Stripe', 'Tailwind'],
        desc: 'E-commerce moderno com pagamentos, painel admin, estoque e relatórios.'
      },
      {
        id: 2,
        cat: 'sites',
        title: 'Site Corporativo',
        subtitle: 'Presença Digital',
        icon: 'fas fa-building',
        gradient: 'linear-gradient(135deg, #f59e0b, #d97706)',
        tags: ['React', 'Framer Motion', 'CMS'],
        desc: 'Site institucional com animações, blog e área de clientes.'
      },
      {
        id: 3,
        cat: 'sites',
        title: 'Dashboard SaaS',
        subtitle: 'Painel Administrativo',
        icon: 'fas fa-chart-line',
        gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
        tags: ['Next.js', 'Tailwind', 'Prisma', 'PostgreSQL'],
        desc: 'Dashboard completo com gráficos em tempo real e gerenciamento de usuários.'
      },
      {
        id: 4,
        cat: 'sites',
        title: 'Landing Page',
        subtitle: 'Página de Vendas',
        icon: 'fas fa-rocket',
        gradient: 'linear-gradient(135deg, #ec4899, #db2777)',
        tags: ['React', 'GSAP', 'Tailwind', 'Vite'],
        desc: 'Landing page de alta conversão com animações premium e formulário inteligente.'
      }
    ],
    automacoes: [
      {
        id: 1,
        cat: 'automacoes',
        title: 'Relatórios Auto',
        subtitle: 'Automação de Dados',
        icon: 'fas fa-robot',
        gradient: 'linear-gradient(135deg, #10b981, #059669)',
        tags: ['Python', 'Pandas', 'Selenium'],
        desc: 'Coleta automática de dados e geração de relatórios enviados por email.'
      },
      {
        id: 2,
        cat: 'automacoes',
        title: 'Automação WhatsApp',
        subtitle: 'Bot de Mensagens',
        icon: 'fab fa-whatsapp',
        gradient: 'linear-gradient(135deg, #25D366, #128C7E)',
        tags: ['Node.js', 'Puppeteer', 'WhatsApp API'],
        desc: 'Automação de envio de mensagens e respostas automáticas via WhatsApp.'
      },
      {
        id: 3,
        cat: 'automacoes',
        title: 'Web Scraper',
        subtitle: 'Extração de Dados',
        icon: 'fas fa-spider',
        gradient: 'linear-gradient(135deg, #f97316, #ea580c)',
        tags: ['Python', 'BeautifulSoup', 'Scrapy'],
        desc: 'Extração automatizada de dados de sites com agendamento e exportação.'
      },
      {
        id: 4,
        cat: 'automacoes',
        title: 'Planilhas Auto',
        subtitle: 'Google Sheets Automation',
        icon: 'fas fa-table',
        gradient: 'linear-gradient(135deg, #0F9D58, #0B8043)',
        tags: ['Python', 'gspread', 'Google API'],
        desc: 'Integração automática com Google Sheets para atualização de dados em tempo real.'
      }
    ]
  };

  // Monta lista de projetos
  let listaProjetos = [];
  if (categoria === 'todos') {
    // Todos os projetos de todas as categorias
    listaProjetos = [
      ...projetos.botsdiscord,
      ...projetos.sites,
      ...projetos.automacoes
    ];
  } else {
    listaProjetos = projetos[categoria] || [];
  }

  // Paginação
  const totalProjetos = listaProjetos.length;
  const totalPaginas = Math.ceil(totalProjetos / projetosPorPagina);
  const inicio = (paginaAtual - 1) * projetosPorPagina;
  const fim = inicio + projetosPorPagina;
  const projetosPagina = listaProjetos.slice(inicio, fim);

  // Gera controles de paginação
  function renderPagination() {
    if (totalPaginas <= 1) return '';

    let pages = [];
    
    // Botão anterior
    if (paginaAtual > 1) {
      pages.push(`<a href="?page=${paginaAtual - 1}" class="btn btn-secondary"><i class="fas fa-chevron-left"></i> Anterior</a>`);
    } else {
      pages.push(`<span class="btn btn-secondary" style="opacity: 0.5; cursor: not-allowed;"><i class="fas fa-chevron-left"></i> Anterior</span>`);
    }

    // Números das páginas
    for (let i = 1; i <= totalPaginas; i++) {
      if (i === paginaAtual) {
        pages.push(`<span class="btn btn-primary">${i}</span>`);
      } else {
        pages.push(`<a href="?page=${i}" class="btn btn-secondary">${i}</a>`);
      }
    }

    // Botão próximo
    if (paginaAtual < totalPaginas) {
      pages.push(`<a href="?page=${paginaAtual + 1}" class="btn btn-secondary">Próximo <i class="fas fa-chevron-right"></i></a>`);
    } else {
      pages.push(`<span class="btn btn-secondary" style="opacity: 0.5; cursor: not-allowed;">Próximo <i class="fas fa-chevron-right"></i></span>`);
    }

    return `
      <div style="display: flex; justify-content: center; align-items: center; gap: 8px; margin-top: 40px; flex-wrap: wrap;">
        ${pages.join('')}
      </div>
      <p style="text-align: center; color: var(--text-ter); font-size: 0.9rem; margin-top: 16px;">
        Mostrando ${inicio + 1}-${Math.min(fim, totalProjetos)} de ${totalProjetos} projetos
      </p>
    `;
  }

  // Gera card de projeto
  function renderProjetoCard(p) {
    const catInfo = categorias[p.cat];
    const linkBase = isCategoryPage ? './' : `./${p.cat}/`;
    
    return `
      <a href="${linkBase}${p.id}" class="portfolio-card" style="text-decoration: none; color: inherit; display: block;">
        <div class="portfolio-visual" style="background: ${p.gradient}; height: 180px;">
          <i class="${p.icon}" style="font-size: 4rem; color: rgba(255,255,255,0.9);"></i>
        </div>
        <div class="portfolio-content">
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
            <span class="tag" style="background: ${catInfo.color}20; border-color: ${catInfo.color}; color: ${catInfo.color}; font-size: 0.75rem; padding: 4px 10px;">
              <i class="${catInfo.icon}" style="margin-right: 4px;"></i> ${catInfo.nome}
            </span>
          </div>
          <div class="portfolio-header">
            <div class="portfolio-icon" style="background: ${p.gradient}; width: 48px; height: 48px;">
              <i class="${p.icon}" style="font-size: 1.25rem; color: #fff;"></i>
            </div>
            <div>
              <div class="portfolio-title" style="font-weight: 600; font-size: 1.2rem;">${p.title}</div>
              <div class="portfolio-subtitle">${p.subtitle}</div>
            </div>
          </div>
          <p style="color: var(--text-sec); font-size: 0.95rem; margin-bottom: 16px; line-height: 1.6;">${p.desc}</p>
          <div class="portfolio-tags">
            ${p.tags.map(t => `<span class="tag">${t}</span>`).join('')}
          </div>
          <div style="margin-top: 16px; text-align: right;">
            <span style="color: var(--accent); font-size: 0.9rem; font-weight: 500;">
              Ver projeto <i class="fas fa-arrow-right"></i>
            </span>
          </div>
        </div>
      </a>
    `;
  }

  app.innerHTML = `
    ${renderNavbar('portfolio')}

    <section class="hero" style="min-height: auto; padding: 140px 24px 40px;">
      <div class="hero-content">
        <span class="section-label">Portfólio</span>
        <h1 style="font-size: clamp(2rem, 5vw, 3.5rem);">
          <i class="${current.icon}" style="color: var(--accent);"></i> ${current.nome}
        </h1>
        <p style="margin-bottom: 32px;">
          ${categoria === 'todos' 
            ? 'Todos os projetos de todas as categorias em um só lugar.' 
            : 'Projetos reais entregues com excelência.'}
        </p>
        
        <!-- Filtros -->
        <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
          <a href="${todosHref}" class="btn ${categoria === 'todos' ? 'btn-primary' : 'btn-secondary'}">Todos</a>
          <a href="${categoryBase}botsdiscord/" class="btn ${categoria === 'botsdiscord' ? 'btn-primary' : 'btn-secondary'}">
            <i class="fab fa-discord"></i> Bots
          </a>
          <a href="${categoryBase}sites/" class="btn ${categoria === 'sites' ? 'btn-primary' : 'btn-secondary'}">
            <i class="fas fa-globe"></i> Sites
          </a>
          <a href="${categoryBase}automacoes/" class="btn ${categoria === 'automacoes' ? 'btn-primary' : 'btn-secondary'}">
            <i class="fas fa-robot"></i> Automações
          </a>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top: 0;">
      <div class="portfolio-grid" style="max-width: 1100px;">
        ${projetosPagina.map(p => renderProjetoCard(p)).join('')}
      </div>
      
      ${renderPagination()}
      
      ${projetosPagina.length === 0 ? `
        <div style="text-align: center; padding: 60px 24px;">
          <i class="fas fa-folder-open" style="font-size: 4rem; color: var(--text-ter); margin-bottom: 16px;"></i>
          <p style="color: var(--text-sec);">Nenhum projeto nesta categoria ainda.</p>
        </div>
      ` : ''}
    </section>

    <section class="section" style="background: var(--bg-sec); text-align: center;">
      <span class="section-label">Vamos criar</span>
      <h2 style="margin-bottom: 16px;">Quer seu projeto aqui?</h2>
      <p style="color: var(--text-sec); max-width: 500px; margin: 0 auto 32px;">Vamos criar algo incrível juntos. Orçamento gratuito e sem compromisso.</p>
      <a href="/pages/contato/" class="btn btn-primary" style="padding: 14px 32px; font-size: 1rem;">
        <i class="fas fa-paper-plane"></i> Iniciar projeto
      </a>
    </section>

    ${renderFooter(false)}
  `;
})();
