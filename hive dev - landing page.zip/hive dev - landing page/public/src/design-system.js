/**
 * HIVE DEV - DESIGN SYSTEM PROFISSIONAL v6
 * Tema Claro/Escuro + Consistência Total
 */

// Apply theme IMMEDIATELY before any rendering to prevent flash
(function() {
  const saved = localStorage.getItem('hive-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
})();

(function() {
  'use strict';

  // ===== THEME MANAGEMENT =====
  const Theme = {
    init() {
      // Check if theme was already applied by inline script in HTML
      const alreadyApplied = document.documentElement.getAttribute('data-theme');
      if (alreadyApplied) {
        // Ensure background color is set inline to prevent flash
        document.documentElement.style.backgroundColor = alreadyApplied === 'light' ? '#ffffff' : '#0a0a0a';
        this.updateIcon(alreadyApplied);
        this.updateLogos(alreadyApplied);
        return;
      }
      // Otherwise, apply theme as usual
      const saved = localStorage.getItem('hive-theme');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      
      // Auto theme by hour (6am - 6pm = light, 6pm - 6am = dark)
      const hour = new Date().getHours();
      const autoTheme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
      
      // Priority: saved > system preference > auto by hour
      const theme = saved || (prefersDark ? 'dark' : autoTheme);
      
      this.set(theme);
      
      // Listen for system changes
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        if (!localStorage.getItem('hive-theme')) {
          this.set(e.matches ? 'dark' : 'light');
        }
      });
      
      // Auto switch by hour
      this.startAutoTheme();
    },
    
    set: function(theme) {
      document.documentElement.setAttribute('data-theme', theme);
      document.documentElement.style.backgroundColor = theme === 'light' ? '#ffffff' : '#0a0a0a';
      document.body.style.backgroundColor = theme === 'light' ? '#ffffff' : '#0a0a0a';
      
      // Update theme toggle icon
      const icon = document.getElementById('theme-icon');
      if (icon) {
        icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
      }
      
      // Update logos
      this.updateLogos(theme);
    },
    
    toggle: function() {
      const current = document.documentElement.getAttribute('data-theme');
      const newTheme = current === 'dark' ? 'light' : 'dark';
      localStorage.setItem('hive-theme', newTheme);
      this.set(newTheme);
    },
    
    updateIcon: function(theme) {
      const icon = document.getElementById('theme-icon');
      if (icon) {
        icon.className = theme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
      }
    },
    
    updateLogos: function(theme) {
      const logos = document.querySelectorAll('[data-logo-dark][data-logo-light]');
      logos.forEach((img) => {
        const darkSrc = img.getAttribute('data-logo-dark');
        const lightSrc = img.getAttribute('data-logo-light');
        const next = theme === 'dark' ? darkSrc : lightSrc;
        if (next) img.setAttribute('src', next);
      });
    },
    
    startAutoTheme: function() {
      // Check every minute for theme change
      setInterval(() => {
        if (!localStorage.getItem('hive-theme')) {
          const hour = new Date().getHours();
          const autoTheme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
          const current = document.documentElement.getAttribute('data-theme');
          
          if (current !== autoTheme) {
            this.set(autoTheme);
          }
        }
      }, 60000); // Check every minute
    }
  };

  // ===== DESIGN SYSTEM CSS =====
  const STYLES = `
    /* Prevent flash of wrong theme - apply background immediately */
    :root[data-theme="light"] {
      background: #ffffff;
    }
    :root[data-theme="dark"],
    :root:not([data-theme]) {
      background: #0a0a0a;
    }
    
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
    
    /* ===== VARIABLES ===== */
    :root {
      /* Cores Base */
      --accent: #00d9ff;
      --accent-sec: #00b8e6;
      --accent-glow: rgba(0, 217, 255, 0.4);
      
      /* Tema Escuro (Default) */
      --bg: #0a0a0a;
      --bg-sec: #111111;
      --bg-card: rgba(255, 255, 255, 0.03);
      --text: #ffffff;
      --text-sec: rgba(255, 255, 255, 0.7);
      --text-ter: rgba(255, 255, 255, 0.5);
      --border: rgba(255, 255, 255, 0.1);
      --nav-bg: rgba(10, 10, 10, 0.85);
    }
    
    :root[data-theme="light"] {
      --bg: #ffffff;
      --bg-sec: #f5f5f5;
      --bg-card: rgba(0, 0, 0, 0.05);
      --text: #0a0a0a;
      --text-sec: rgba(10, 10, 10, 0.7);
      --text-ter: rgba(10, 10, 10, 0.5);
      --border: rgba(0, 0, 0, 0.15);
      --nav-bg: rgba(255, 255, 255, 0.9);
      --accent: #0066aa;
      --accent-sec: #005599;
      --accent-glow: rgba(0, 102, 170, 0.3);
    }
    
    /* ===== RESET & BASE ===== */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { 
      scroll-behavior: auto;
      scroll-padding-top: 80px;
    }
    
    /* Favicon - aumentado para melhor visualização */
    link[rel="icon"] {
      width: 48px;
      height: 48px;
    }
    
    /* Footer link hover animation */
    .footer-link {
      transition: color 0.25s ease;
      position: relative;
      width: fit-content;
    }
    .footer-link:hover {
      color: var(--accent) !important;
    }
    .footer-link::after {
      content: '';
      position: absolute;
      bottom: -2px;
      left: 0;
      height: 2px;
      background: var(--accent);
      transform: scaleX(0);
      transform-origin: left;
      transition: transform 0.25s ease;
    }
    .footer-link:hover::after {
      transform: scaleX(1);
    }
    
    /* Footer social hover animation */
    .footer-social {
      transition: all 0.3s ease;
    }
    .footer-social:hover {
      transform: translateY(-4px) scale(1.1);
      border-color: var(--accent);
      color: var(--accent) !important;
      box-shadow: 0 8px 20px rgba(0, 217, 255, 0.25);
    }
    
    /* ===== PERFORMANCE OPTIMIZATIONS ===== */
    img {
      image-rendering: -webkit-optimize-contrast;
      image-rendering: optimize-contrast;
    }
    
    /* ===== SCROLLBAR CUSTOMIZADA ===== */
    ::-webkit-scrollbar {
      width: 6px;
    }
    ::-webkit-scrollbar-track {
      background: transparent;
    }
    ::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 3px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.3);
    }
    [data-theme="light"] ::-webkit-scrollbar-thumb {
      background: rgba(0, 0, 0, 0.2);
    }
    [data-theme="light"] ::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 0, 0, 0.3);
    }
    
    body {
      font-family: 'Inter', -apple-system, sans-serif;
      background: #0a0a0a;
      color: var(--text);
      line-height: 1.6;
      min-height: 100vh;
      transition: background-color 0.3s ease, color 0.3s ease;
    }
    [data-theme="light"] body {
      background: #ffffff;
    }
    [data-theme="dark"] body {
      background: #0a0a0a;
    }

    body::before {
      content: none;
    }

    body::after {
      content: none;
    }
    
    /* ===== NAVBAR PADRÃO (TODAS PÁGINAS) ===== */
    .nav {
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
      width: 900px;
      max-width: calc(100vw - 32px);
      height: 60px;
      padding: 0 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 24px;
      background: var(--nav-bg);
      backdrop-filter: blur(20px);
      border: 1px solid var(--border);
      border-radius: 100px;
      transition: all 0.3s ease;
      box-sizing: border-box;
    }
    .nav:hover { border-color: var(--accent); box-shadow: 0 8px 32px rgba(0, 217, 255, 0.15); }
    
    .nav-brand {
      display: flex;
      align-items: center;
      gap: 10px;
      text-decoration: none;
      flex-shrink: 0;
    }
    .nav-brand img { 
      height: 56px; 
      width: auto; 
      display: block; 
      filter: drop-shadow(0 2px 8px rgba(0, 217, 255, 0.3));
      transition: transform 0.3s ease, filter 0.3s ease;
    }
    .nav-brand:hover img {
      transform: scale(1.05);
      filter: drop-shadow(0 4px 12px rgba(0, 217, 255, 0.5));
    }
    .nav-brand span {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 1.1rem;
      font-weight: 600;
      color: var(--text);
      white-space: nowrap;
    }
    
    .nav-links {
      display: flex;
      align-items: center;
      gap: 4px;
      list-style: none;
      margin: 0;
      padding: 0;
    }
    .nav-links a {
      padding: 8px 16px;
      font-size: 0.875rem;
      font-weight: 500;
      color: var(--text-sec);
      text-decoration: none;
      border-radius: 100px;
      transition: all 0.2s;
      white-space: nowrap;
      display: block;
    }
    .nav-links a:hover { color: var(--text); background: var(--bg-card); }
    .nav-links a.active { color: var(--accent); background: rgba(0, 217, 255, 0.1); }
    
    .nav-actions {
      display: flex;
      align-items: center;
      gap: 12px;
      flex-shrink: 0;
      width: 180px;
      justify-content: flex-end;
    }
    
    .theme-toggle {
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 50%;
      color: var(--text-sec);
      cursor: pointer;
      transition: all 0.2s;
      font-size: 0.9rem;
    }
    .theme-toggle:hover { border-color: var(--accent); color: var(--accent); }
    
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 20px;
      font-size: 0.875rem;
      font-weight: 600;
      border-radius: 100px;
      border: none;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.2s;
      white-space: nowrap;
    }
    .btn-primary {
      background: var(--accent);
      color: #000;
    }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 24px var(--accent-glow); }
    .btn-secondary {
      background: transparent;
      color: var(--text);
      border: 1px solid var(--border);
    }
    .btn-secondary:hover { border-color: var(--accent); color: var(--accent); }
    
    .mobile-toggle {
      display: none;
      width: 36px;
      height: 36px;
      align-items: center;
      justify-content: center;
      background: none;
      border: none;
      color: var(--text);
      font-size: 1.25rem;
      cursor: pointer;
    }
    
    /* ===== HERO PADRÃO ===== */
    .hero {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 140px 24px 80px;
      text-align: center;
      position: relative;
      z-index: 1;
    }
    .hero-content { max-width: 800px; }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 8px 16px;
      background: rgba(0, 217, 255, 0.1);
      border: 1px solid var(--accent);
      border-radius: 100px;
      font-size: 0.8rem;
      font-weight: 500;
      color: var(--accent);
      margin-bottom: 24px;
      animation: fadeUp 0.6s ease forwards;
    }
    .badge::before {
      content: '';
      width: 6px;
      height: 6px;
      background: var(--accent);
      border-radius: 50%;
      animation: pulse 2s infinite;
    }
    @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
    
    .hero h1 {
      font-family: 'Space Grotesk', sans-serif;
      font-size: clamp(2.5rem, 6vw, 4.5rem);
      font-weight: 700;
      line-height: 1.1;
      margin-bottom: 20px;
    }
    .hero h1 span { color: var(--accent); }
    
    .hero p {
      font-size: 1.1rem;
      color: var(--text-sec);
      max-width: 500px;
      margin: 0 auto 32px;
    }
    .hero-buttons {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }
    
    /* ===== SECTION PADRÃO ===== */
    .section {
      padding: 100px 24px;
      position: relative;
      z-index: 1;
    }
    .section-header {
      text-align: center;
      max-width: 600px;
      margin: 0 auto 60px;
    }
    .section-label {
      display: inline-block;
      padding: 6px 14px;
      background: rgba(0, 217, 255, 0.1);
      border: 1px solid var(--accent);
      border-radius: 100px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: var(--accent);
      margin-bottom: 16px;
    }
    .section h2 {
      font-family: 'Space Grotesk', sans-serif;
      font-size: clamp(1.75rem, 4vw, 2.5rem);
      font-weight: 700;
    }
    
    /* ===== CARDS PADRÃO ===== */
    .cards-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 32px;
      transition: all 0.3s ease;
    }
    .card:hover {
      border-color: var(--accent);
      transform: translateY(-8px);
      box-shadow: 0 20px 40px rgba(0, 217, 255, 0.1);
    }
    .card-icon {
      width: 56px;
      height: 56px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(0, 217, 255, 0.1);
      border: 1px solid var(--accent);
      border-radius: 16px;
      color: var(--accent);
      font-size: 1.5rem;
      margin-bottom: 20px;
      transition: all 0.3s;
    }
    .card:hover .card-icon {
      background: var(--accent);
      color: #000;
    }
    .card h3 {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 12px;
    }
    .card p {
      font-size: 0.95rem;
      color: var(--text-sec);
      line-height: 1.6;
    }
    
    /* ===== PORTFOLIO CARDS ===== */
    .portfolio-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 24px;
      max-width: 1000px;
      margin: 0 auto;
    }
    .portfolio-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 20px;
      overflow: hidden;
      transition: all 0.3s ease;
    }
    .portfolio-card:hover {
      border-color: var(--accent);
      transform: translateY(-8px);
      box-shadow: 0 20px 40px rgba(0, 217, 255, 0.1);
    }
    .portfolio-visual {
      height: 180px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 4rem;
      color: rgba(255, 255, 255, 0.3);
      transition: transform 0.3s;
    }
    [data-theme="light"] .portfolio-visual { color: rgba(0, 0, 0, 0.2); }
    .portfolio-card:hover .portfolio-visual { transform: scale(1.1); }
    .portfolio-content { padding: 24px; }
    .portfolio-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;
    }
    .portfolio-icon {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.25rem;
      color: #fff;
    }
    .portfolio-title { font-weight: 600; }
    .portfolio-subtitle { font-size: 0.85rem; color: var(--text-ter); }
    .portfolio-tags {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    .tag {
      padding: 4px 12px;
      background: var(--bg-sec);
      border: 1px solid var(--border);
      border-radius: 100px;
      font-size: 0.7rem;
      font-weight: 500;
      color: var(--text-sec);
    }
    
    /* ===== FORM PADRÃO ===== */
    .form-container {
      max-width: 500px;
      margin: 0 auto;
    }
    .form-group {
      margin-bottom: 20px;
    }
    .form-group label {
      display: block;
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--text-sec);
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 12px 16px;
      background: var(--bg-sec);
      border: 1px solid var(--border);
      border-radius: 12px;
      color: var(--text);
      font-size: 1rem;
      transition: all 0.2s;
    }
    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: var(--accent);
    }
    .form-group textarea { min-height: 120px; resize: vertical; }
    .btn-full { width: 100%; justify-content: center; }
    
    /* ===== FOOTER PADRÃO ===== */
    .footer {
      padding: 40px 24px;
      border-top: 1px solid var(--border);
      position: relative;
      z-index: 1;
    }
    .footer-content {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 24px;
    }
    .footer-brand img:hover {
      transform: scale(1.05);
      filter: drop-shadow(0 4px 10px rgba(0, 217, 255, 0.4));
    }
    
    .footer-brand {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .footer-brand span {
      font-family: 'Space Grotesk', sans-serif;
      font-weight: 600;
      font-size: 1.1rem;
    }
    .footer-links {
      display: flex;
      gap: 32px;
    }
    .footer-links a {
      font-size: 0.9rem;
      color: var(--text-sec);
      text-decoration: none;
      transition: color 0.2s;
    }
    .footer-links a:hover { color: var(--accent); }
    .footer-social {
      display: flex;
      gap: 12px;
    }
    .footer-social a {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 50%;
      color: var(--text-sec);
      text-decoration: none;
      transition: all 0.2s;
    }
    .footer-social a:hover {
      border-color: var(--accent);
      color: var(--accent);
    }
    
    /* ===== RESPONSIVE ===== */
    @media (max-width: 768px) {
      .nav {
        width: calc(100vw - 32px);
        height: 56px;
        padding: 0 16px;
        border-radius: 28px;
      }
      .nav-brand { width: auto; }
      .nav-links {
        display: none;
        position: absolute;
        top: calc(100% + 8px);
        left: 0;
        right: 0;
        flex-direction: column;
        background: var(--nav-bg);
        backdrop-filter: blur(20px);
        border: 1px solid var(--border);
        border-radius: 20px;
        padding: 16px;
      }
      .nav-links.open { display: flex; }
      .mobile-toggle { display: flex; }
      .theme-toggle { display: none; }
      .nav .btn-primary { display: none; }
      .nav-actions { width: auto; }
      
      .cards-grid { grid-template-columns: 1fr; }
      .portfolio-grid { grid-template-columns: 1fr; }
      .footer-content { flex-direction: column; text-align: center; }
      .footer-links { gap: 20px; }
    }
  `;

  const style = document.createElement('style');
  style.textContent = STYLES;
  document.head.appendChild(style);

  const fa = document.createElement('link');
  fa.rel = 'stylesheet';
  fa.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css';
  document.head.appendChild(fa);

  // ===== RENDER NAVBAR =====
  function renderNavbar(currentPage) {
    const pages = [
      { id: 'home', label: 'Home', href: '/' },
      { id: 'servicos', label: 'Serviços', href: '/servicos/' },
      { id: 'portfolio', label: 'Portfólio', href: '/portfolio/' },
      { id: 'contato', label: 'Contato', href: '/contato/' },
    ];

    const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
    const logoWhite = '/public/assets/hive dev - logo branca.png';
    const logoBlack = '/public/assets/hive dev - logo preta.png';
    const logoPath = currentTheme === 'dark' ? logoWhite : logoBlack;

    // Add prefetch for all pages except current
    const prefetchLinks = pages
      .filter(p => p.id !== currentPage)
      .map(p => `<link rel="prefetch" href="${p.href}">`)
      .join('\n    ');

    // Inject prefetch links
    if (!document.querySelector('link[rel="prefetch"][href*=".html"]')) {
      const prefetchContainer = document.createElement('div');
      prefetchContainer.innerHTML = prefetchLinks;
      prefetchContainer.querySelectorAll('link').forEach(link => {
        document.head.appendChild(link);
      });
    }

    return `
      <nav class="nav">
        <a href="/" class="nav-brand">
          <img
            src="${logoPath}"
            alt="Hive Dev"
            id="nav-logo"
            data-logo-dark="${logoWhite}"
            data-logo-light="${logoBlack}"
          >
          <span>Hive Dev</span>
        </a>
        <ul class="nav-links" id="nav-links">
          ${pages.map(p => `
            <li><a href="${p.href}" class="${p.id === currentPage ? 'active' : ''}" data-page="${p.id}">${p.label}</a></li>
          `).join('')}
        </ul>
        <div class="nav-actions">
          <button class="theme-toggle" id="theme-toggle" aria-label="Alternar tema">
            <i class="fas fa-moon" id="theme-icon"></i>
          </button>
          <a href="/contato/" class="btn btn-primary">Orçamento</a>
          <button class="mobile-toggle" id="mobile-toggle" aria-label="Menu">
            <i class="fas fa-bars"></i>
          </button>
        </div>
      </nav>
    `;
  }

  // ===== RENDER FOOTER =====
  function renderFooter(isHome) {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
    const logoWhite = '/public/assets/hive dev - logo branca.png';
    const logoBlack = '/public/assets/hive dev - logo preta.png';
    const logoPath = currentTheme === 'dark' ? logoWhite : logoBlack;
    const year = new Date().getFullYear();

    return `
      <footer class="footer" style="padding: 48px 24px 32px; border-top: 1px solid var(--border);">
        <div class="footer-content" style="max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 40px;">
          
          <!-- Logo e Copyright -->
          <div style="flex: 1; min-width: 200px;">
            <div class="footer-brand" style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
              <img
                src="${logoPath}"
                alt="Hive Dev"
                id="footer-logo"
                data-logo-dark="${logoWhite}"
                data-logo-light="${logoBlack}"
                style="height: 42px; transition: transform 0.3s ease, filter 0.3s ease; filter: drop-shadow(0 2px 6px rgba(0, 217, 255, 0.2));"
              >
              <span style="font-family: 'Space Grotesk', sans-serif; font-weight: 600; font-size: 1.2rem; color: var(--text);">Hive Dev</span>
            </div>
            <p style="font-size: 0.85rem; color: var(--text-ter); line-height: 1.6;">
              © ${year} Hive Dev.<br>Todos os direitos reservados.
            </p>
          </div>

          <!-- Links de Navegação -->
          <div style="display: flex; gap: 48px; flex-wrap: wrap;">
            <div>
              <h4 style="font-size: 0.75rem; font-weight: 600; color: var(--text-ter); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 16px;">Navegação</h4>
              <div style="display: flex; flex-direction: column; gap: 10px;">
                <a href="/" class="footer-link" style="font-size: 0.9rem; color: var(--text-sec); text-decoration: none;">Home</a>
                <a href="/servicos/" class="footer-link" style="font-size: 0.9rem; color: var(--text-sec); text-decoration: none;">Serviços</a>
                <a href="/portfolio/" class="footer-link" style="font-size: 0.9rem; color: var(--text-sec); text-decoration: none;">Portfólio</a>
                <a href="/contato/" class="footer-link" style="font-size: 0.9rem; color: var(--text-sec); text-decoration: none;">Contato</a>
              </div>
            </div>
            
            <div>
              <h4 style="font-size: 0.75rem; font-weight: 600; color: var(--text-ter); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 16px;">Legal</h4>
              <div style="display: flex; flex-direction: column; gap: 10px;">
                <a href="/termos/" class="footer-link" style="font-size: 0.9rem; color: var(--text-sec); text-decoration: none;">Termos de Uso</a>
                <a href="/privacidade/" class="footer-link" style="font-size: 0.9rem; color: var(--text-sec); text-decoration: none;">Privacidade</a>
                <a href="/faq/" class="footer-link" style="font-size: 0.9rem; color: var(--text-sec); text-decoration: none;">FAQ</a>
              </div>
            </div>

            <div>
              <h4 style="font-size: 0.75rem; font-weight: 600; color: var(--text-ter); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 16px;">Redes Sociais</h4>
              <div style="display: flex; gap: 12px;">
                <a href="https://discord.gg/hivedev" target="_blank" class="footer-social" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: var(--bg-card); border: 1px solid var(--border); border-radius: 50%; color: var(--text-sec); text-decoration: none; font-size: 1.1rem;">
                  <i class="fab fa-discord"></i>
                </a>
                <a href="https://instagram.com/hivedevofc" target="_blank" class="footer-social" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: var(--bg-card); border: 1px solid var(--border); border-radius: 50%; color: var(--text-sec); text-decoration: none; font-size: 1.1rem;">
                  <i class="fab fa-instagram"></i>
                </a>
              </div>
            </div>
          </div>

        </div>
      </footer>
    `;
  }

  // ===== INIT =====
  // ===== BACKEND VERIFICATION =====
  const BackendCheck = {
    BACKEND_URL: 'http://localhost:3000/api/ping',
    BYPASS_KEY: 'hive_dev_bypass',
    
    async verify() {
      // Check for bypass in development
      if (localStorage.getItem(this.BYPASS_KEY) === 'dev_mode') {
        return true;
      }
      
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3000);
        
        const response = await fetch(this.BACKEND_URL, {
          method: 'GET',
          signal: controller.signal,
          headers: { 'X-Source': 'hive-dev-client' }
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) {
          throw new Error('Backend unavailable');
        }
        
        const data = await response.json();
        return data.status === 'ok' && data.verified === true;
      } catch (error) {
        console.error('[Hive Dev] Backend verification failed:', error);
        return false;
      }
    },
    
    renderBlockScreen() {
      document.body.innerHTML = `
        <div style="
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: #0a0a0a;
          color: #fff;
          font-family: 'Inter', sans-serif;
          padding: 24px;
          text-align: center;
        ">
          <div style="font-size: 4rem; margin-bottom: 24px;">🔒</div>
          <h1 style="font-size: 1.75rem; margin-bottom: 16px; color: #00d9ff;">Acesso Negado</h1>
          <p style="color: rgba(255,255,255,0.7); max-width: 400px; line-height: 1.6; margin-bottom: 24px;">
            Este site requer um backend autorizado para funcionar. 
            O sistema não detectou uma conexão válida com o servidor.
          </p>
          <div style="
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 20px;
            max-width: 400px;
            font-size: 0.85rem;
            color: rgba(255,255,255,0.5);
            font-family: monospace;
          ">
            Error: BACKEND_CONNECTION_FAILED<br>
            Code: 503_SERVICE_UNAVAILABLE
          </div>
          <p style="color: rgba(255,255,255,0.4); font-size: 0.75rem; margin-top: 24px;">
            Hive Dev - Protected Content
          </p>
        </div>
      `;
    }
  };

  // Initialize theme immediately (before backend check)
  Theme.init();
  
  // Then verify backend
  (async function init() {
    const isValid = await BackendCheck.verify();
    if (!isValid) {
      BackendCheck.renderBlockScreen();
      return;
    }
  })();

  // Event listeners
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a[href]');
    if (link) {
      const href = link.getAttribute('href');
      const currentPath = window.location.pathname.replace(/\/$/, '');
      const linkPath = href.replace(/\/$/, '');
      
      if (currentPath === linkPath || href === '/' && (currentPath === '' || currentPath === '/')) {
        e.preventDefault();
        return;
      }
    }
    
    if (e.target.closest('#theme-toggle')) {
      Theme.toggle();
    }
    if (e.target.closest('#mobile-toggle')) {
      document.getElementById('nav-links')?.classList.toggle('open');
    }
  });

  // Optimized navigation with preloading
  document.addEventListener('mouseover', (e) => {
    const navLink = e.target.closest('.nav-links a[data-page]');
    if (navLink && !navLink.dataset.preloaded) {
      const href = navLink.getAttribute('href');
      if (href && href !== window.location.pathname) {
        // Preload page on hover
        const link = document.createElement('link');
        link.rel = 'prefetch';
        link.href = href;
        document.head.appendChild(link);
        navLink.dataset.preloaded = 'true';
      }
    }
  });

  // Expose for pages
  window.HiveDesign = { renderNavbar, renderFooter, Theme };
})();
