// FAQ Page Script
document.addEventListener('DOMContentLoaded', () => {
  const { renderNavbar, renderFooter, Theme } = window.HiveDesign;
  
  // Initialize theme system
  Theme.init();
  
  // FAQ Data
  const faqData = [
    {
      category: "Pagamento",
      questions: [
        {
          question: "Como funciona o pagamento?",
          answer: "Trabalhamos com pagamento parcelado em até 12x no cartão de crédito ou com desconto para pagamento à vista via PIX/transferência bancária. O pagamento é dividido em marcos do projeto: 40% no início, 30% na entrega intermediária e 30% na entrega final."
        },
        {
          question: "Quais formas vocês aceitam?",
          answer: "Aceitamos cartão de crédito (até 12x), PIX, transferência bancária, boleto bancário e criptomoedas (Bitcoin, Ethereum). Para projetos maiores, também negociamos condições especiais de pagamento."
        },
        {
          question: "Preciso pagar tudo de uma vez?",
          answer: "Não! Trabalhamos com pagamentos parcelados conforme o andamento do projeto. Geralmente dividimos em 3 etapas: início, meio e conclusão. Isso garante segurança para ambos e mantém o fluxo do projeto organizado."
        }
      ]
    },
    {
      category: "Projeto",
      questions: [
        {
          question: "Quanto tempo leva?",
          answer: "O tempo varia conforme a complexidade: Sites institucionais (2-4 semanas), E-commerce (6-12 semanas), Aplicativos web (8-16 semanas), Sistemas personalizados (12-24 semanas). Apresentamos um cronograma detalhado no início do projeto."
        },
        {
          question: "Usam templates prontos?",
          answer: "Não desenvolvemos com templates prontos. Todos os nossos projetos são 100% personalizados e desenvolvidos do zero, garantindo exclusividade, performance otimizada e código limpo que atende exatamente às necessidades do seu negócio."
        },
        {
          question: "Posso pedir alterações durante?",
          answer: "Sim! Incluímos até 3 rodadas de revisão em cada marco do projeto. Alterações fora do escopo inicial podem ser orçadas separadamente. Mantemos uma comunicação constante para alinhar expectativas durante todo o processo."
        },
        {
          question: "Recebo o código fonte?",
          answer: "Sim! Ao final do projeto você recebe 100% do código fonte, documentação completa, acesso a todos os repositórios e treinamento para sua equipe. Todo o material é seu, sem custos adicionais ou restrições de uso."
        }
      ]
    },
    {
      category: "Suporte",
      questions: [
        {
          question: "Como funciona o suporte?",
          answer: "Oferecemos 3 meses de suporte gratuito pós-lançamento. Inclui correção de bugs, pequenos ajustes e suporte técnico. Após esse período, temos planos de manutenção mensal ou suporte sob demanda para garantir seu sistema sempre atualizado."
        },
        {
          question: "E se algo parar de funcionar?",
          answer: "Nosso SLA (Service Level Agreement) garante resposta em até 24h úteis para problemas críticos e 48h para questões gerais. Temos equipe de plantão e sistemas de monitoramento para identificar e resolver problemas rapidamente."
        },
        {
          question: "Como entro em contato?",
          answer: "Você pode nos contatar por: E-mail (contato@hivedev.com), WhatsApp (11) 9999-9999, Discord (servidor exclusivo para clientes), ou através do nosso portal do cliente onde pode abrir tickets e acompanhar o andamento do projeto."
        }
      ]
    }
  ];

  // Render page
  const app = document.getElementById('app');
  app.innerHTML = `
    ${renderNavbar(false)}
    
    <main style="min-height: calc(100vh - 200px); padding: 120px 24px 80px;">
      <div style="max-width: 900px; margin: 0 auto;">
        <!-- Header -->
        <div style="text-align: center; margin-bottom: 64px;">
          <h1 style="font-size: 3rem; font-weight: 700; color: var(--text); margin-bottom: 16px; line-height: 1.1;">
            Perguntas <span style="color: var(--accent);">Frequentes</span>
          </h1>
          <p style="font-size: 1.2rem; color: var(--text-sec); max-width: 600px; margin: 0 auto;">
            Tire suas dúvidas sobre nossos serviços, processos e formas de trabalho
          </p>
        </div>

        <!-- FAQ Categories -->
        <div style="display: flex; flex-direction: column; gap: 48px;">
          ${faqData.map(category => `
            <div>
              <h2 style="font-size: 1.8rem; font-weight: 600; color: var(--text); margin-bottom: 24px; display: flex; align-items: center; gap: 12px;">
                <span style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: var(--accent); color: white; border-radius: 10px; font-size: 1.2rem;">
                  ${category.category === 'Pagamento' ? '<i class="fas fa-credit-card"></i>' : 
                    category.category === 'Projeto' ? '<i class="fas fa-code"></i>' : 
                    '<i class="fas fa-headset"></i>'}
                </span>
                ${category.category}
              </h2>
              
              <div style="display: flex; flex-direction: column; gap: 16px;">
                ${category.questions.map((item, index) => `
                  <div class="faq-item" style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; transition: all 0.3s;">
                    <button class="faq-question" style="width: 100%; padding: 20px 24px; background: transparent; border: none; text-align: left; cursor: pointer; display: flex; align-items: center; justify-content: space-between; gap: 16px; transition: all 0.3s;">
                      <span style="font-size: 1.1rem; color: var(--text); font-weight: 500;">${item.question}</span>
                      <i class="fas fa-chevron-down" style="color: var(--text-sec); transition: transform 0.3s; font-size: 0.9rem;"></i>
                    </button>
                    <div class="faq-answer" style="max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out;">
                      <div style="padding: 0 24px 20px;">
                        <p style="color: var(--text-sec); line-height: 1.6; margin: 0;">${item.answer}</p>
                      </div>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>

        <!-- Contact CTA -->
        <div style="margin-top: 80px; padding: 48px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; text-align: center;">
          <h3 style="font-size: 1.5rem; color: var(--text); margin-bottom: 16px;">Ainda tem dúvidas?</h3>
          <p style="color: var(--text-sec); margin-bottom: 32px;">Nossa equipe está pronta para ajudar! Entre em contato e tire todas as suas dúvidas.</p>
          <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
            <a href="/contato/" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: var(--accent); color: white; text-decoration: none; border-radius: 10px; font-weight: 500; transition: all 0.3s;">
              <i class="fas fa-envelope"></i>
              Fale Conosco
            </a>
            <a href="https://discord.gg/hivedev" target="_blank" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: var(--bg-sec); color: var(--text); text-decoration: none; border: 1px solid var(--border); border-radius: 10px; font-weight: 500; transition: all 0.3s;">
              <i class="fab fa-discord"></i>
              Discord
            </a>
          </div>
        </div>
      </div>
    </main>

    ${renderFooter(false)}
  `;

  // FAQ Accordion functionality
  const faqItems = document.querySelectorAll('.faq-item');
  
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    const answer = item.querySelector('.faq-answer');
    const icon = item.querySelector('.fa-chevron-down');
    
    question.addEventListener('click', () => {
      const isOpen = answer.style.maxHeight && answer.style.maxHeight !== '0px';
      
      // Close all other items
      faqItems.forEach(otherItem => {
        if (otherItem !== item) {
          const otherAnswer = otherItem.querySelector('.faq-answer');
          const otherIcon = otherItem.querySelector('.fa-chevron-down');
          otherAnswer.style.maxHeight = '0px';
          otherIcon.style.transform = 'rotate(0deg)';
          otherItem.style.borderColor = 'var(--border)';
        }
      });
      
      // Toggle current item
      if (isOpen) {
        answer.style.maxHeight = '0px';
        icon.style.transform = 'rotate(0deg)';
        item.style.borderColor = 'var(--border)';
      } else {
        answer.style.maxHeight = answer.scrollHeight + 'px';
        icon.style.transform = 'rotate(180deg)';
        item.style.borderColor = 'var(--accent)';
      }
    });
  });

  // Theme switcher for footer logo
  const themeToggle = document.getElementById('theme-toggle');
  const footerLogo = document.getElementById('footer-logo');
  
  if (themeToggle && footerLogo) {
    themeToggle.addEventListener('click', () => {
      setTimeout(() => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const logoWhite = '/public/assets/hive dev - logo branca.png';
        const logoBlack = '/public/assets/hive dev - logo preta.png';
        footerLogo.src = currentTheme === 'dark' ? logoWhite : logoBlack;
      }, 100);
    });
  }
});
