(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  app.innerHTML = `
    ${renderNavbar('404')}

    <section class="hero" style="min-height: auto; padding: 160px 24px 60px; flex: 1; display: flex; align-items: center;">
      <div class="hero-content">
        <span class="section-label">Erro 404</span>
        <h1 style="font-size: clamp(2.2rem, 6vw, 4rem); margin-bottom: 12px;">
          Página <span style="color: var(--accent);">não encontrada</span>.
        </h1>
        <p style="max-width: 720px; margin: 0 auto 28px; color: var(--text-sec);">
          O link que você tentou acessar não existe ou foi movido.
        </p>

        <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
          <a href="/" class="btn btn-primary">
            <i class="fas fa-home"></i> Voltar para Home
          </a>
          <a href="/portfolio/" class="btn btn-secondary">
            <i class="fas fa-briefcase"></i> Ver Portfólio
          </a>
          <a href="/contato/" class="btn btn-secondary">
            <i class="fas fa-paper-plane"></i> Falar com a gente
          </a>
        </div>
      </div>
    </section>

    ${renderFooter(false)}
  `;
})();
