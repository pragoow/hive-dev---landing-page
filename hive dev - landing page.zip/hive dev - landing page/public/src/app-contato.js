/**
 * HIVE DEV - PÁGINA DE CONTATO
 * Design melhorado sem formulário
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  app.innerHTML = `
    ${renderNavbar('contato')}

    <!-- Hero Section -->
    <section class="hero" style="min-height: auto; padding: 140px 24px 100px;">
      <div class="hero-content">
        <span class="section-label">Contato</span>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4rem); margin-bottom: 24px; font-weight: 700;">
          Entre em <span style="color: var(--accent);">contato</span>
        </h1>
        <p style="max-width: 600px; margin: 0 auto 40px; color: var(--text-sec); font-size: 1.3rem; line-height: 1.6;">
          Tem um projeto em mente? Vamos conversar e transformar sua ideia em realidade!
        </p>
      </div>
    </section>

    <!-- Cards de Contato Principais -->
    <section class="section" style="background: var(--bg-sec); padding: 80px 24px;">
      <div style="max-width: 1200px; margin: 0 auto;">
        <div style="text-align: center; margin-bottom: 60px;">
          <h2 style="font-size: 2.5rem; color: var(--text); margin-bottom: 16px; font-weight: 600;">Nossos Canais de Contato</h2>
          <p style="color: var(--text-sec); font-size: 1.2rem;">Escolha a forma que preferir para conversar com a gente</p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 40px; max-width: 800px; margin: 0 auto;">
          
          <!-- Card Discord -->
          <div class="card" style="
            text-align: center; 
            padding: 50px 40px; 
            border-radius: 20px;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
          " onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 20px 40px rgba(0,0,0,0.1)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='var(--card-shadow)'">
            <div style="
              width: 90px;
              height: 90px;
              background: linear-gradient(135deg, #5865F2, #4752C4);
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              margin: 0 auto 30px;
              box-shadow: 0 10px 25px rgba(88,101,242,0.3);
            ">
              <i class="fab fa-discord" style="font-size: 2.5rem; color: white;"></i>
            </div>
            <h3 style="color: var(--text); margin-bottom: 16px; font-size: 1.5rem; font-weight: 600;">Discord</h3>
            <p style="color: var(--text-ter); font-size: 1rem; margin-bottom: 25px; line-height: 1.6;">
              Chat em tempo real para conversas rápidas e suporte direto
            </p>
            <a href="https://discord.gg/hivedev" target="_blank" class="btn btn-primary" style="padding: 12px 30px; border-radius: 25px;">
              <i class="fab fa-discord" style="margin-right: 8px;"></i>
              Entrar no Discord
            </a>
          </div>

          <!-- Card Instagram -->
          <div class="card" style="
            text-align: center; 
            padding: 50px 40px; 
            border-radius: 20px;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
          " onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 20px 40px rgba(0,0,0,0.1)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='var(--card-shadow)'">
            <div style="
              width: 90px;
              height: 90px;
              background: linear-gradient(135deg, #E4405F, #C13584, #833AB4, #5851DB, #405DE6);
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              margin: 0 auto 30px;
              box-shadow: 0 10px 25px rgba(228,64,95,0.3);
            ">
              <i class="fab fa-instagram" style="font-size: 2.5rem; color: white;"></i>
            </div>
            <h3 style="color: var(--text); margin-bottom: 16px; font-size: 1.5rem; font-weight: 600;">Instagram</h3>
            <p style="color: var(--text-ter); font-size: 1rem; margin-bottom: 25px; line-height: 1.6;">
              Acompanhe nossos projetos, atualizações e bastidores
            </p>
            <a href="https://instagram.com/hivedevofc" target="_blank" class="btn btn-primary" style="padding: 12px 30px; border-radius: 25px;">
              <i class="fab fa-instagram" style="margin-right: 8px;"></i>
              Seguir no Instagram
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- Seção CTA Final -->
    <section class="section">
      <div style="max-width: 800px; margin: 0 auto; text-align: center;">
        <div class="card" style="padding: 60px 40px;">
          <i class="fas fa-code" style="font-size: 3rem; color: var(--accent); margin-bottom: 24px;"></i>
          <h2 style="font-size: 2.2rem; margin-bottom: 20px; font-weight: 600; color: var(--text);">Pronto para transformar sua ideia?</h2>
          <p style="font-size: 1.2rem; margin-bottom: 32px; color: var(--text-sec); line-height: 1.6;">
            Veja nossos projetos anteriores ou converse diretamente com a gente. Sem compromisso, sem pressão.
          </p>
          <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: nowrap;">
            <a href="/portfolio/" class="btn btn-primary">
              <i class="fas fa-briefcase" style="margin-right: 8px;"></i>
              Ver Portfólio
            </a>
            <a href="https://discord.gg/hivedev" target="_blank" class="btn btn-secondary">
              <i class="fab fa-discord" style="margin-right: 8px;"></i>
              Conversar Agora
            </a>
          </div>
        </div>
      </div>
    </section>

    ${renderFooter(false)}
  `;
})();
