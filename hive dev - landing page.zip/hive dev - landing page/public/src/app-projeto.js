/**
 * HIVE DEV - PÁGINA DE PROJETO INDIVIDUAL
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  // Detecta categoria e ID pela URL
  const path = window.location.pathname;
  const pathParts = path.split('/');
  const categoria = pathParts[pathParts.length - 2] || 'botsdiscord';
  const projetoId = parseInt(pathParts[pathParts.length - 1]) || 1;

  const categorias = {
    botsdiscord: { nome: 'Bots Discord', icon: 'fab fa-discord' },
    sites: { nome: 'Sites & Web', icon: 'fas fa-globe' },
    automacoes: { nome: 'Automações', icon: 'fas fa-robot' }
  };

  const catInfo = categorias[categoria] || { nome: 'Projeto', icon: 'fas fa-code' };

  // Base de projetos (mesma da categoria)
  const projetos = {
    botsdiscord: {
      1: {
        title: 'Moderação Pro',
        subtitle: 'Bot Discord Premium',
        icon: 'fab fa-discord',
        gradient: 'linear-gradient(135deg, #5865F2, #4752C4)',
        tags: ['Discord.js', 'Node.js', 'MongoDB', 'Redis', 'TypeScript'],
        desc: 'Sistema completo de moderação para Discord com recursos avançados de auto-moderação, sistema de níveis XP, economia virtual, loja de itens, e dashboard web para gerenciamento.',
        features: [
          'Moderação automática com detecção de spam e raid',
          'Sistema de níveis XP com rankings e recompensas',
          'Economia virtual com loja e transações',
          'Música do Spotify/YouTube com alta qualidade',
          'Sistema de tickets com categorias personalizadas',
          'Dashboard web responsivo para configuração'
        ],
        tech: [
          { name: 'Discord.js', desc: 'Framework principal do bot' },
          { name: 'Node.js', desc: 'Runtime JavaScript' },
          { name: 'MongoDB', desc: 'Banco de dados NoSQL' },
          { name: 'Redis', desc: 'Cache e dados em tempo real' },
          { name: 'TypeScript', desc: 'Tipagem estática' }
        ],
        client: 'Comunidade de 50k+ membros',
        duration: '3 semanas',
        year: '2025'
      },
      2: {
        title: 'Bot de Música',
        subtitle: 'Discord Music Bot',
        icon: 'fas fa-music',
        gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
        tags: ['Discord.js', 'Lavalink', 'Spotify API', 'YouTube API'],
        desc: 'Bot de música premium com suporte a múltiplas plataformas, filtros de áudio avançados e sistema de playlists personalizadas.',
        features: [
          'Reprodução do Spotify, YouTube e SoundCloud',
          'Filtros de áudio: bass boost, nightcore, vaporwave',
          'Playlists personalizadas salvas no banco de dados',
          'Busca por letra de música',
          'Equalizador com presets',
          'Autoplay baseado em preferências'
        ],
        tech: [
          { name: 'Discord.js', desc: 'Framework do bot' },
          { name: 'Lavalink', desc: 'Servidor de áudio' },
          { name: 'Spotify API', desc: 'Integração Spotify' },
          { name: 'PostgreSQL', desc: 'Banco de dados' }
        ],
        client: 'Servidor privado',
        duration: '2 semanas',
        year: '2025'
      },
      3: {
        title: 'Sistema de Level',
        subtitle: 'Gamificação Discord',
        icon: 'fas fa-trophy',
        gradient: 'linear-gradient(135deg, #ec4899, #db2777)',
        tags: ['Discord.js', 'Redis', 'Canvas', 'MongoDB'],
        desc: 'Sistema completo de gamificação com cards de perfil gerados dinamicamente, rankings globais e recompensas automáticas por cargo.',
        features: [
          'Cards de perfil personalizados gerados com Canvas',
          'Sistema de níveis com fórmula de XP progressiva',
          'Rankings globais e por servidor',
          'Recompensas automáticas (cargos, permissões)',
          'Backgrounds customizáveis',
          'Integração com economia'
        ],
        tech: [
          { name: 'Discord.js', desc: 'Framework do bot' },
          { name: 'Redis', desc: 'Cache de XP em tempo real' },
          { name: 'Canvas', desc: 'Geração de imagens' },
          { name: 'MongoDB', desc: 'Persistência de dados' }
        ],
        client: 'Comunidade de games',
        duration: '2 semanas',
        year: '2025'
      },
      4: {
        title: 'Sistema de Tickets',
        subtitle: 'Suporte Discord',
        icon: 'fas fa-ticket-alt',
        gradient: 'linear-gradient(135deg, #06b6d4, #0891b2)',
        tags: ['Discord.js', 'TypeScript', 'MongoDB'],
        desc: 'Sistema avançado de tickets com múltiplas categorias, transcrição automática e integração com sistema de suporte externo.',
        features: [
          'Múltiplas categorias de tickets configuráveis',
          'Transcrição automática de conversas',
          'Atribuição automática de atendentes',
          'Sistema de avaliação de atendimento',
          'Integração com plataforma de suporte',
          'Estatísticas e relatórios de suporte'
        ],
        tech: [
          { name: 'Discord.js', desc: 'Framework do bot' },
          { name: 'TypeScript', desc: 'Tipagem estática' },
          { name: 'MongoDB', desc: 'Banco de dados' },
          { name: 'Node.js', desc: 'Runtime' }
        ],
        client: 'Empresa de software',
        duration: '1 semana',
        year: '2025'
      },
      5: {
        title: 'Bot de Economia',
        subtitle: 'Economia Virtual Discord',
        icon: 'fas fa-coins',
        gradient: 'linear-gradient(135deg, #fbbf24, #f59e0b)',
        tags: ['Discord.js', 'MongoDB', 'Canvas'],
        desc: 'Sistema completo de economia virtual com loja, inventário, cassino, trabalhos e transferências entre usuários.',
        features: [
          'Sistema de moeda virtual completo',
          'Loja de itens com inventário',
          'Minigames: roleta, blackjack, slots',
          'Sistema de trabalhos e tarefas diárias',
          'Transferências e doações entre usuários',
          'Leaderboards de riqueza'
        ],
        tech: [
          { name: 'Discord.js', desc: 'Framework do bot' },
          { name: 'MongoDB', desc: 'Banco de dados' },
          { name: 'Canvas', desc: 'Geração de imagens' }
        ],
        client: 'Comunidade RPG',
        duration: '2 semanas',
        year: '2025'
      }
    },
    sites: {
      1: {
        title: 'Loja Virtual',
        subtitle: 'E-commerce Completo',
        icon: 'fas fa-shopping-bag',
        gradient: 'linear-gradient(135deg, #3b82f6, #2563eb)',
        tags: ['Next.js', 'Stripe', 'Tailwind', 'PostgreSQL', 'Prisma'],
        desc: 'E-commerce moderno e completo com integração de pagamentos, painel administrativo, controle de estoque em tempo real e relatórios de vendas detalhados.',
        features: [
          'Checkout com Stripe (cartão, PIX, boleto)',
          'Painel administrativo completo',
          'Controle de estoque em tempo real',
          'Relatórios de vendas e analytics',
          'Carrinho persistente',
          'Notificações por email e WhatsApp'
        ],
        tech: [
          { name: 'Next.js', desc: 'Framework React' },
          { name: 'Stripe', desc: 'Processamento de pagamentos' },
          { name: 'Tailwind', desc: 'Estilização CSS' },
          { name: 'PostgreSQL', desc: 'Banco de dados' },
          { name: 'Prisma', desc: 'ORM' }
        ],
        client: 'Empresa de moda',
        duration: '3 semanas',
        year: '2025'
      },
      2: {
        title: 'Site Corporativo',
        subtitle: 'Presença Digital',
        icon: 'fas fa-building',
        gradient: 'linear-gradient(135deg, #f59e0b, #d97706)',
        tags: ['React', 'Framer Motion', 'CMS', 'TypeScript'],
        desc: 'Site institucional moderno com animações suaves, blog integrado com CMS, área de clientes e formulários inteligentes.',
        features: [
          'Design moderno com animações suaves',
          'Blog integrado com CMS headless',
          'Área de clientes com login',
          'Formulários com validação',
          'SEO otimizado',
          'Analytics integrado'
        ],
        tech: [
          { name: 'React', desc: 'Biblioteca UI' },
          { name: 'Framer Motion', desc: 'Animações' },
          { name: 'Strapi', desc: 'CMS' },
          { name: 'TypeScript', desc: 'Tipagem' }
        ],
        client: 'Empresa de tecnologia',
        duration: '2 semanas',
        year: '2025'
      },
      3: {
        title: 'Dashboard SaaS',
        subtitle: 'Painel Administrativo',
        icon: 'fas fa-chart-line',
        gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
        tags: ['Next.js', 'Tailwind', 'Prisma', 'PostgreSQL', 'Recharts'],
        desc: 'Dashboard completo para SaaS com gráficos em tempo real, gerenciamento de usuários, assinaturas e analytics detalhados.',
        features: [
          'Gráficos e visualizações de dados em tempo real',
          'Gerenciamento completo de usuários',
          'Controle de assinaturas e planos',
          'Sistema de notificações',
          'Exportação de relatórios PDF/Excel',
          'Modo escuro/claro integrado'
        ],
        tech: [
          { name: 'Next.js', desc: 'Framework full-stack' },
          { name: 'Tailwind', desc: 'Estilização' },
          { name: 'Prisma', desc: 'ORM' },
          { name: 'PostgreSQL', desc: 'Banco de dados' },
          { name: 'Recharts', desc: 'Gráficos' }
        ],
        client: 'Startup de analytics',
        duration: '3 semanas',
        year: '2025'
      },
      4: {
        title: 'Landing Page',
        subtitle: 'Página de Vendas',
        icon: 'fas fa-rocket',
        gradient: 'linear-gradient(135deg, #ec4899, #db2777)',
        tags: ['React', 'GSAP', 'Tailwind', 'Vite'],
        desc: 'Landing page de alta conversão com animações premium, formulário de captura integrado com email marketing e testes A/B.',
        features: [
          'Design focado em conversão',
          'Animações premium com GSAP',
          'Formulário com validação em tempo real',
          'Integração com email marketing',
          'Otimização para mobile-first',
          'Analytics de comportamento'
        ],
        tech: [
          { name: 'React', desc: 'Biblioteca UI' },
          { name: 'GSAP', desc: 'Animações avançadas' },
          { name: 'Tailwind', desc: 'Estilização' },
          { name: 'Vite', desc: 'Build tool' }
        ],
        client: 'Curso online',
        duration: '1 semana',
        year: '2025'
      }
    },
    automacoes: {
      1: {
        title: 'Relatórios Automáticos',
        subtitle: 'Automação de Dados',
        icon: 'fas fa-robot',
        gradient: 'linear-gradient(135deg, #10b981, #059669)',
        tags: ['Python', 'Pandas', 'Selenium', 'n8n', 'PostgreSQL'],
        desc: 'Sistema de automação que coleta dados de múltiplas fontes, processa automaticamente e gera relatórios diários enviados por email.',
        features: [
          'Web scraping de múltiplas fontes',
          'Processamento de dados com Pandas',
          'Geração de relatórios em PDF e Excel',
          'Envio automático por email',
          'Agendamento com cron jobs',
          'Dashboard de monitoramento'
        ],
        tech: [
          { name: 'Python', desc: 'Linguagem principal' },
          { name: 'Pandas', desc: 'Processamento de dados' },
          { name: 'Selenium', desc: 'Automação de navegador' },
          { name: 'n8n', desc: 'Workflow automation' },
          { name: 'PostgreSQL', desc: 'Armazenamento' }
        ],
        client: 'Agência de marketing',
        duration: '1 semana',
        year: '2025'
      }
    }
  };

  const projeto = projetos[categoria]?.[projetoId];

  if (!projeto) {
    app.innerHTML = `
      ${renderNavbar('portfolio')}
      <section class="hero">
        <h1>Projeto não encontrado</h1>
        <a href="/portfolio/" class="btn btn-primary">Voltar para categoria</a>
      </section>
      ${renderFooter(false)}
    `;
    return;
  }

  app.innerHTML = `
    ${renderNavbar('portfolio')}

    <section class="hero" style="min-height: auto; padding: 140px 24px 40px;">
      <div class="hero-content">
        <div style="margin-bottom: 16px;">
          <a href="/portfolio/" style="color: var(--text-sec); text-decoration: none; font-size: 0.9rem;">
            <i class="fas fa-arrow-left"></i> Voltar para ${catInfo.nome}
          </a>
        </div>
        <div class="badge">
          <i class="${catInfo.icon}"></i> ${catInfo.nome}
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4rem); margin-bottom: 16px;">
          ${projeto.title}
        </h1>
        <p style="font-size: 1.2rem; margin-bottom: 8px;">${projeto.subtitle}</p>
        <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; color: var(--text-ter); font-size: 0.9rem;">
          <span><i class="fas fa-calendar"></i> ${projeto.year}</span>
          <span><i class="fas fa-clock"></i> ${projeto.duration}</span>
          <span><i class="fas fa-user"></i> ${projeto.client}</span>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top: 0;">
      <div style="max-width: 900px; margin: 0 auto;">
        <!-- Visual do projeto -->
        <div style="background: ${projeto.gradient}; border-radius: 24px; height: 350px; display: flex; align-items: center; justify-content: center; margin-bottom: 48px;">
          <i class="${projeto.icon}" style="font-size: 8rem; color: rgba(255,255,255,0.9);"></i>
        </div>

        <!-- Descrição -->
        <div class="card" style="margin-bottom: 32px;">
          <h3 style="font-size: 1.5rem; margin-bottom: 16px; color: var(--accent);">
            <i class="fas fa-info-circle"></i> Sobre o projeto
          </h3>
          <p style="color: var(--text-sec); font-size: 1.1rem; line-height: 1.8;">
            ${projeto.desc}
          </p>
        </div>

        <!-- Funcionalidades -->
        <div class="card" style="margin-bottom: 32px;">
          <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">
            <i class="fas fa-check-circle"></i> Funcionalidades
          </h3>
          <ul style="list-style: none; padding: 0;">
            ${projeto.features.map(f => `
              <li style="padding: 12px 0; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 12px; color: var(--text-sec);">
                <i class="fas fa-check" style="color: var(--accent);"></i>
                ${f}
              </li>
            `).join('')}
          </ul>
        </div>

        <!-- Tecnologias -->
        <div class="card" style="margin-bottom: 32px;">
          <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">
            <i class="fas fa-code"></i> Tecnologias utilizadas
          </h3>
          <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px;">
            ${projeto.tech.map(t => `
              <div style="background: var(--bg-sec); border: 1px solid var(--border); border-radius: 12px; padding: 16px;">
                <div style="font-weight: 600; margin-bottom: 4px;">${t.name}</div>
                <div style="font-size: 0.85rem; color: var(--text-ter);">${t.desc}</div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- CTA -->
        <div style="text-align: center;">
          <h3 style="font-size: 1.5rem; margin-bottom: 16px;">Gostou do projeto?</h3>
          <p style="color: var(--text-sec); margin-bottom: 24px;">Entre em contato e vamos criar algo incrível juntos.</p>
          <a href="/contato/" class="btn btn-primary" style="padding: 14px 32px; font-size: 1rem;">
            <i class="fas fa-paper-plane"></i> Solicitar orçamento
          </a>
        </div>
      </div>
    </section>

    <!-- Navegação entre projetos -->
    <section class="section" style="background: var(--bg-sec); padding: 48px 24px;">
      <div style="max-width: 1100px; margin: 0 auto;">
        
        <!-- Grid de navegação -->
        <div style="display: grid; grid-template-columns: 1fr auto 1fr; gap: 24px; align-items: stretch;">
          
          <!-- Projeto Anterior -->
          <div style="display: flex; flex-direction: column; justify-content: center;">
            ${projetoId > 1 ? `
              <a href="./${projetoId - 1}" style="text-decoration: none; display: flex; align-items: center; gap: 16px; padding: 20px; background: var(--bg); border: 1px solid var(--border); border-radius: 16px; transition: all 0.2s;" onmouseover="this.style.borderColor='var(--accent)'; this.style.transform='translateX(-4px)'" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='translateX(0)'">
                <div style="width: 56px; height: 56px; border-radius: 12px; background: ${projetos[categoria][projetoId - 1]?.gradient || 'var(--bg-sec)'}; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                  <i class="${projetos[categoria][projetoId - 1]?.icon || 'fas fa-code'}" style="font-size: 1.5rem; color: #fff;"></i>
                </div>
                <div style="text-align: left;">
                  <span style="font-size: 0.75rem; color: var(--text-ter); text-transform: uppercase; letter-spacing: 0.1em;">← Anterior</span>
                  <div style="font-weight: 600; color: var(--text); margin-top: 4px;">${projetos[categoria][projetoId - 1]?.title || 'Projeto'}</div>
                </div>
              </a>
            ` : `<div></div>`}
          </div>
          
          <!-- Ver Todos (Centro) -->
          <div style="display: flex; align-items: center; justify-content: center;">
            <a href="./" class="btn btn-secondary" style="padding: 12px 24px; white-space: nowrap;">
              <i class="fas fa-th-large"></i> Ver todos
            </a>
          </div>
          
          <!-- Próximo Projeto -->
          <div style="display: flex; flex-direction: column; justify-content: center;">
            ${projetos[categoria][projetoId + 1] ? `
              <a href="./${projetoId + 1}" style="text-decoration: none; display: flex; align-items: center; gap: 16px; padding: 20px; background: var(--bg); border: 1px solid var(--border); border-radius: 16px; transition: all 0.2s;" onmouseover="this.style.borderColor='var(--accent)'; this.style.transform='translateX(4px)'" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='translateX(0)'">
                <div style="text-align: right; flex: 1;">
                  <span style="font-size: 0.75rem; color: var(--text-ter); text-transform: uppercase; letter-spacing: 0.1em;">Próximo →</span>
                  <div style="font-weight: 600; color: var(--text); margin-top: 4px;">${projetos[categoria][projetoId + 1]?.title || 'Projeto'}</div>
                </div>
                <div style="width: 56px; height: 56px; border-radius: 12px; background: ${projetos[categoria][projetoId + 1]?.gradient || 'var(--bg-sec)'}; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                  <i class="${projetos[categoria][projetoId + 1]?.icon || 'fas fa-code'}" style="font-size: 1.5rem; color: #fff;"></i>
                </div>
              </a>
            ` : `<div></div>`}
          </div>
          
        </div>
      </div>
    </section>

    ${renderFooter(false)}
  `;
})();
