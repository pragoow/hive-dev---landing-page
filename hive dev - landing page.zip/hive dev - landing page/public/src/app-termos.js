/**
 * HIVE DEV - TERMOS DE SERVIÇO
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  app.innerHTML = `
    ${renderNavbar('termos')}

    <section class="hero" style="min-height: auto; padding: 140px 24px 60px;">
      <div class="hero-content">
        <span class="section-label">Legal</span>
        <h1 style="font-size: clamp(2rem, 5vw, 3.5rem);">
          Termos de <span style="color: var(--accent);">Serviço</span>
        </h1>
        <p style="margin-bottom: 0;">Última atualização: 19 de Março de 2026</p>
      </div>
    </section>

    <section class="section" style="padding-top: 0; max-width: 800px; margin: 0 auto;">
      <div class="card" style="text-align: left;">
        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">1. Aceitação dos Termos</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          Ao contratar os serviços da Hive Dev, você concorda com estes Termos de Serviço. Se não concordar com qualquer parte destes termos, não poderá utilizar nossos serviços.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">2. Descrição dos Serviços</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          A Hive Dev oferece serviços de desenvolvimento de software, incluindo bots para Discord, sites web, aplicações web e automações. O escopo exato de cada projeto será definido em proposta específica acordada entre as partes.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">3. Orçamentos e Pagamentos</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          <strong>3.1.</strong> Todos os orçamentos são válidos por 7 dias após a data de emissão.
        </p>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          <strong>3.2.</strong> O pagamento é dividido em duas partes: 50% de entrada para iniciar o projeto e 50% na entrega final.
        </p>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          <strong>3.3.</strong> Aceitamos pagamento via Pix e transferência bancária. O projeto só será iniciado após a confirmação do pagamento da entrada.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">4. Prazos e Entregas</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          <strong>4.1.</strong> Os prazos estimados serão informados no orçamento e podem variar conforme a complexidade do projeto.
        </p>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          <strong>4.2.</strong> Atrasos na entrega de informações ou feedback pelo cliente podem estender o prazo do projeto.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">5. Garantia e Suporte</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          <strong>5.1.</strong> Oferecemos garantia de 30 dias após a entrega para correção de bugs e ajustes.
        </p>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          <strong>5.2.</strong> O suporte pós-garantia pode ser contratado separadamente mediante plano de manutenção mensal.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">6. Propriedade Intelectual</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          Após a entrega completa e pagamento total, todos os direitos do código desenvolvido são transferidos para o cliente. A Hive Dev reserva-se o direito de usar o projeto como exemplo em portfólio, salvo acordo em contrário.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">7. Cancelamento</h3>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 16px;">
          <strong>7.1.</strong> O cliente pode cancelar o projeto a qualquer momento.
        </p>
        <p style="color: var(--text-sec); line-height: 1.8; margin-bottom: 24px;">
          <strong>7.2.</strong> Em caso de cancelamento após o início do desenvolvimento, a entrada não será reembolsada, mas o trabalho realizado até o momento será entregue ao cliente.
        </p>

        <h3 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--accent);">8. Contato</h3>
        <p style="color: var(--text-sec); line-height: 1.8;">
          Para dúvidas sobre estes termos, entre em contato pelo Discord ou Instagram listados no rodapé do site.
        </p>
      </div>
    </section>

    ${renderFooter(false)}
  `;
})();
