/**
 * HIVE DEV - PORTFOLIO PROJETO INDIVIDUAL
 * Página dinâmica para exibir detalhes de cada projeto
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  // Detecta categoria e ID do projeto pela URL
  const path = window.location.pathname;
  const categoriaMatch = path.match(/\/portfolio\/(botsdiscord|sites|automacoes)\/(\d+)/);
  
  if (!categoriaMatch) {
    // Redireciona para portfolio se URL inválida
    window.location.href = '/portfolio/';
    return;
  }

  const [, categoria, id] = categoriaMatch;
  const projectId = parseInt(id);

  // Dados dos projetos
  const projetos = {
    botsdiscord: [
      {
        id: 1,
        title: 'Moderação Pro',
        subtitle: 'Bot Discord Premium',
        icon: 'fab fa-discord',
        gradient: 'linear-gradient(135deg, #5865F2, #4752C4)',
        tags: ['Discord.js', 'Node.js', 'MongoDB'],
        desc: 'Sistema completo de moderação com auto-moderação, níveis, economia e dashboard web.',
        detalhes: {
          cliente: 'Comunidade Gaming BR',
          duracao: '3 meses',
          status: 'Concluído',
          tecnologias: ['Discord.js', 'Node.js', 'MongoDB', 'Express', 'Socket.io', 'Canvas'],
          funcionalidades: [
            'Auto-moderação com IA',
            'Sistema de níveis e XP',
            'Economia virtual completa',
            'Dashboard web administrativo',
            'Sistema de tickets',
            'Logs detalhados',
            'Backup automático',
            'API REST completa'
          ],
          resultado: 'Redução de 95% em moderação manual, aumento de 300% no engajamento dos usuários.'
        }
      },
      {
        id: 2,
        title: 'Bot de Música',
        subtitle: 'Discord Music Bot',
        icon: 'fas fa-music',
        gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
        tags: ['Discord.js', 'Lavalink', 'Spotify API'],
        desc: 'Reprodução de alta qualidade com suporte a Spotify, YouTube, playlists e filtros de áudio.',
        detalhes: {
          cliente: 'Servidor de Música',
          duracao: '2 meses',
          status: 'Concluído',
          tecnologias: ['Discord.js', 'Lavalink', 'Spotify API', 'YouTube API', 'FFmpeg'],
          funcionalidades: [
            'Reprodução de Spotify/YouTube',
            'Playlists personalizadas',
            'Filtros de áudio profissionais',
            'Letras sincronizadas',
            'Queue management',
            '24/7 uptime',
            'Equalizador customizável',
            'Radio streaming'
          ],
          resultado: 'Mais de 50.000 músicas tocadas mensalmente, 99.9% uptime.'
        }
      },
      {
        id: 3,
        title: 'Sistema de Level',
        subtitle: 'Gamificação Discord',
        icon: 'fas fa-trophy',
        gradient: 'linear-gradient(135deg, #ec4899, #db2777)',
        tags: ['Discord.js', 'Redis', 'Canvas'],
        desc: 'Sistema de níveis com cards de perfil, rankings e recompensas automáticas.',
        detalhes: {
          cliente: 'RPG Community',
          duracao: '1.5 meses',
          status: 'Concluído',
          tecnologias: ['Discord.js', 'Redis', 'Canvas', 'Chart.js', 'Node-cache'],
          funcionalidades: [
            'Sistema de XP baseado em atividade',
            'Cards de perfil customizáveis',
            'Rankings globais e por categoria',
            'Sistema de conquistas',
            'Loja de recompensas',
            'Eventos especiais',
            'Integração com stream',
            'API de estatísticas'
          ],
          resultado: 'Aumento de 250% na retenção de usuários, média de 4h diárias de atividade.'
        }
      },
      {
        id: 4,
        title: 'Sistema de Tickets',
        subtitle: 'Suporte Discord',
        icon: 'fas fa-ticket-alt',
        gradient: 'linear-gradient(135deg, #06b6d4, #0891b2)',
        tags: ['Discord.js', 'TypeScript', 'MongoDB'],
        desc: 'Sistema avançado de tickets com múltiplas categorias e transcrição automática.',
        detalhes: {
          cliente: 'Empresa de Tecnologia',
          duracao: '2 meses',
          status: 'Concluído',
          tecnologias: ['Discord.js', 'TypeScript', 'MongoDB', 'PDF-lib', 'Node-cron'],
          funcionalidades: [
            'Múltiplas categorias de suporte',
            'Transcrição automática para PDF',
            'Sistema de avaliação',
            'SLA tracking',
            'Notificações personalizadas',
            'Knowledge base integrada',
            'Relatórios de performance',
            'Integração com email'
          ],
          resultado: 'Redução de 60% no tempo de resposta, 98% de satisfação dos clientes.'
        }
      },
      {
        id: 5,
        title: 'Bot de Economia',
        subtitle: 'Economia Virtual Discord',
        icon: 'fas fa-coins',
        gradient: 'linear-gradient(135deg, #fbbf24, #f59e0b)',
        tags: ['Discord.js', 'MongoDB', 'Canvas'],
        desc: 'Economia virtual completa com loja, inventário, cassino e trabalhos.',
        detalhes: {
          cliente: 'Crypto Gaming Server',
          duracao: '3 meses',
          status: 'Concluído',
          tecnologias: ['Discord.js', 'MongoDB', 'Canvas', 'Crypto-js', 'Node-schedule'],
          funcionalidades: [
            'Sistema de moeda virtual',
            'Loja com 200+ itens',
            'Inventário completo',
            'Mini-cassino com 5 jogos',
            'Sistema de trabalhos',
            'Mercado P2P',
            'Eventos de economia',
            'Gráficos de mercado'
          ],
          resultado: 'Economia estável com inflação <2%, 10.000 transações diárias.'
        }
      }
    ],
    sites: [
      {
        id: 1,
        title: 'Loja Virtual',
        subtitle: 'E-commerce Completo',
        icon: 'fas fa-shopping-bag',
        gradient: 'linear-gradient(135deg, #3b82f6, #2563eb)',
        tags: ['Next.js', 'Stripe', 'Tailwind'],
        desc: 'E-commerce moderno com pagamentos, painel admin, estoque e relatórios.',
        detalhes: {
          cliente: 'Moda Express',
          duracao: '4 meses',
          status: 'Concluído',
          tecnologias: ['Next.js', 'Stripe', 'Tailwind CSS', 'Prisma', 'PostgreSQL', 'NextAuth'],
          funcionalidades: [
            'Catálogo com 500+ produtos',
            'Sistema de pagamentos Stripe',
            'Painel administrativo completo',
            'Gestão de estoque em tempo real',
            'Sistema de avaliações',
            'Filtros avançados',
            'Wishlist personalizada',
            'Relatórios de vendas'
          ],
          resultado: 'Aumento de 180% nas vendas, tempo de carregamento <1.5s, taxa de conversão 3.2%.'
        }
      },
      {
        id: 2,
        title: 'Site Corporativo',
        subtitle: 'Presença Digital',
        icon: 'fas fa-building',
        gradient: 'linear-gradient(135deg, #f59e0b, #d97706)',
        tags: ['React', 'Framer Motion', 'CMS'],
        desc: 'Site institucional com animações, blog e área de clientes.',
        detalhes: {
          cliente: 'Tech Solutions SA',
          duracao: '2.5 meses',
          status: 'Concluído',
          tecnologias: ['React', 'Framer Motion', 'Strapi CMS', 'Node.js', 'MySQL'],
          funcionalidades: [
            'Design responsivo premium',
            'Animações customizadas',
            'Blog integrado',
            'Área de clientes',
            'Sistema de agendamentos',
            'Galeria de projetos',
            'Formulários inteligentes',
            'SEO otimizado'
          ],
          resultado: 'Primeiro lugar no Google para 5 keywords principais, aumento de 300% em leads.'
        }
      },
      {
        id: 3,
        title: 'Dashboard SaaS',
        subtitle: 'Painel Administrativo',
        icon: 'fas fa-chart-line',
        gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
        tags: ['Next.js', 'Tailwind', 'Prisma', 'PostgreSQL'],
        desc: 'Dashboard completo com gráficos em tempo real e gerenciamento de usuários.',
        detalhes: {
          cliente: 'Data Analytics Pro',
          duracao: '5 meses',
          status: 'Concluído',
          tecnologias: ['Next.js', 'Tailwind CSS', 'Prisma', 'PostgreSQL', 'Chart.js', 'Socket.io'],
          funcionalidades: [
            'Gráficos em tempo real',
            'Gestão de usuários',
            'Relatórios customizáveis',
            'Exportação de dados',
            'Notificações push',
            'Dark/Light mode',
            'API RESTful',
            'Autenticação 2FA'
          ],
          resultado: 'Processamento de 1M+ dados/dia, redução de 40% no tempo de análise.'
        }
      },
      {
        id: 4,
        title: 'Landing Page',
        subtitle: 'Página de Vendas',
        icon: 'fas fa-rocket',
        gradient: 'linear-gradient(135deg, #ec4899, #db2777)',
        tags: ['React', 'GSAP', 'Tailwind', 'Vite'],
        desc: 'Landing page de alta conversão com animações premium e formulário inteligente.',
        detalhes: {
          cliente: 'Startup Tech',
          duracao: '1.5 meses',
          status: 'Concluído',
          tecnologias: ['React', 'GSAP', 'Tailwind CSS', 'Vite', 'React Hook Form'],
          funcionalidades: [
            'Animações GSAP premium',
            'Formulário multi-step',
            'A/B testing integrado',
            'Pixels de conversão',
            'Testemunhos dinâmicos',
            'Contador regressivo',
            'Chatbot integrado',
            'Analytics em tempo real'
          ],
          resultado: 'Taxa de conversão 8.5% (média de mercado 2.5%), ROI 350% em 3 meses.'
        }
      }
    ],
    automacoes: [
      {
        id: 1,
        title: 'Relatórios Auto',
        subtitle: 'Automação de Dados',
        icon: 'fas fa-robot',
        gradient: 'linear-gradient(135deg, #10b981, #059669)',
        tags: ['Python', 'Pandas', 'Selenium'],
        desc: 'Coleta automática de dados e geração de relatórios enviados por email.',
        detalhes: {
          cliente: 'Corporação Financeira',
          duracao: '2 meses',
          status: 'Concluído',
          tecnologias: ['Python', 'Pandas', 'Selenium', 'SMTP', 'ReportLab', 'Celery'],
          funcionalidades: [
            'Coleta de 50+ fontes de dados',
            'Processamento 24/7',
            'Relatórios PDF customizados',
            'Envio automático por email',
            'Dashboard de monitoramento',
            'Alertas de anomalias',
            'Histórico completo',
            'API de integração'
          ],
          resultado: 'Economia de 40h/semana em trabalho manual, 99.8% accuracy nos dados.'
        }
      },
      {
        id: 2,
        title: 'Automação WhatsApp',
        subtitle: 'Bot de Mensagens',
        icon: 'fab fa-whatsapp',
        gradient: 'linear-gradient(135deg, #25D366, #128C7E)',
        tags: ['Node.js', 'Puppeteer', 'WhatsApp API'],
        desc: 'Automação de envio de mensagens e respostas automáticas via WhatsApp.',
        detalhes: {
          cliente: 'E-commerce Varejo',
          duracao: '1.5 meses',
          status: 'Concluído',
          tecnologias: ['Node.js', 'Puppeteer', 'WhatsApp Business API', 'MongoDB'],
          funcionalidades: [
            'Envio de 10k mensagens/dia',
            'Respostas automáticas IA',
            'Segmentação de contatos',
            'Agendamento mensagens',
            'Relatórios de entrega',
            ' blacklist automática',
            'Templates personalizados',
            'Integração CRM'
          ],
          resultado: 'Aumento de 200% no engajamento, redução de 80% no tempo de resposta.'
        }
      },
      {
        id: 3,
        title: 'Web Scraper',
        subtitle: 'Extração de Dados',
        icon: 'fas fa-spider',
        gradient: 'linear-gradient(135deg, #f97316, #ea580c)',
        tags: ['Python', 'BeautifulSoup', 'Scrapy'],
        desc: 'Extração automatizada de dados de sites com agendamento e exportação.',
        detalhes: {
          cliente: 'Agência de Marketing',
          duracao: '2 meses',
          status: 'Concluído',
          tecnologias: ['Python', 'Scrapy', 'BeautifulSoup', 'Redis', 'PostgreSQL', 'Airflow'],
          funcionalidades: [
            'Scraping de 1000+ sites/dia',
            'Detecção anti-bot',
            'Processamento paralelo',
            'Exportação CSV/JSON/SQL',
            'Agendamento flexível',
            'Proxy rotation',
            'Data cleaning automático',
            'API REST de consulta'
          ],
          resultado: 'Coleta de 1M+ dados/mês, 99.5% uptime, redução de 90% em custos.'
        }
      },
      {
        id: 4,
        title: 'Planilhas Auto',
        subtitle: 'Google Sheets Automation',
        icon: 'fas fa-table',
        gradient: 'linear-gradient(135deg, #0F9D58, #0B8043)',
        tags: ['Python', 'gspread', 'Google API'],
        desc: 'Integração automática com Google Sheets para atualização de dados em tempo real.',
        detalhes: {
          cliente: 'Startup Fintech',
          duracao: '1 mês',
          status: 'Concluído',
          tecnologias: ['Python', 'gspread', 'Google Sheets API', 'OAuth2', 'APScheduler'],
          funcionalidades: [
            'Sincronização em tempo real',
            'Validação automática',
            'Múltiplas planilhas',
            'Backup automático',
            'Notificações de alterações',
            'Histórico de mudanças',
            'Formatação condicional',
            'Dashboard de status'
          ],
          resultado: 'Atualização de 10k células/hora, zero erros humanos, economia de 20h/semana.'
        }
      }
    ]
  };

  // Busca o projeto
  const projeto = projetos[categoria]?.find(p => p.id === projectId);
  
  if (!projeto) {
    // Redireciona se projeto não encontrado
    window.location.href = '/portfolio/';
    return;
  }

  // CSS específico da página
  const PROJECT_STYLES = `
    .project-hero {
      min-height: 60vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 100px 24px 60px;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .project-hero::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: ${projeto.gradient};
      opacity: 0.1;
      z-index: -1;
    }

    .project-hero .container {
      max-width: 800px;
      position: relative;
      z-index: 1;
    }

    .project-icon {
      width: 80px;
      height: 80px;
      background: ${projeto.gradient};
      border-radius: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2rem;
      color: white;
      margin: 0 auto 24px;
      animation: float 3s ease-in-out infinite;
    }

    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-10px); }
    }

    .project-title {
      font-size: clamp(2rem, 5vw, 3rem);
      font-weight: 700;
      margin-bottom: 16px;
      background: ${projeto.gradient};
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .project-subtitle {
      font-size: 1.2rem;
      color: var(--text-sec);
      margin-bottom: 24px;
    }

    .project-tags {
      display: flex;
      gap: 8px;
      justify-content: center;
      flex-wrap: wrap;
      margin-bottom: 32px;
    }

    .project-tag {
      background: rgba(0, 217, 255, 0.1);
      border: 1px solid rgba(0, 217, 255, 0.2);
      color: var(--accent);
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 500;
    }

    .project-section {
      padding: 80px 24px;
    }

    .project-section .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .project-details {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 40px;
      margin-bottom: 60px;
    }

    .detail-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 32px;
    }

    .detail-card h3 {
      font-size: 1.2rem;
      margin-bottom: 16px;
      color: var(--accent);
    }

    .detail-item {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid var(--border);
    }

    .detail-item:last-child {
      border-bottom: none;
    }

    .detail-label {
      color: var(--text-sec);
      font-weight: 500;
    }

    .detail-value {
      color: var(--text);
      font-weight: 600;
    }

    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 32px;
    }

    .feature-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 20px;
      background: var(--bg-sec);
      border-radius: 12px;
      transition: transform 0.2s ease;
    }

    .feature-item:hover {
      transform: translateY(-2px);
    }

    .feature-icon {
      width: 40px;
      height: 40px;
      background: ${projeto.gradient};
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      flex-shrink: 0;
    }

    .feature-text {
      flex: 1;
    }

    .feature-text h4 {
      font-size: 1rem;
      margin-bottom: 4px;
      color: var(--text);
    }

    .feature-text p {
      font-size: 0.9rem;
      color: var(--text-sec);
      line-height: 1.5;
    }

    .result-box {
      background: ${projeto.gradient};
      color: white;
      padding: 40px;
      border-radius: 20px;
      text-align: center;
      margin-top: 40px;
    }

    .result-box h3 {
      font-size: 1.5rem;
      margin-bottom: 16px;
    }

    .result-box p {
      font-size: 1.1rem;
      line-height: 1.6;
      opacity: 0.95;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--text-sec);
      text-decoration: none;
      margin-bottom: 32px;
      transition: color 0.2s ease;
    }

    .back-link:hover {
      color: var(--accent);
    }

    @media (max-width: 768px) {
      .project-hero { padding: 80px 24px 40px; }
      .project-section { padding: 60px 24px; }
      .project-details { grid-template-columns: 1fr; gap: 24px; }
      .features-grid { grid-template-columns: 1fr; }
      .result-box { padding: 24px; }
    }
  `;

  // Adiciona estilos
  const style = document.createElement('style');
  style.textContent = PROJECT_STYLES;
  document.head.appendChild(style);

  // Renderiza a página
  app.innerHTML = `
    ${renderNavbar('portfolio')}
    
    <section class="project-hero">
      <div class="container">
        <div class="project-icon">
          <i class="${projeto.icon}"></i>
        </div>
        <h1 class="project-title">${projeto.title}</h1>
        <p class="project-subtitle">${projeto.subtitle}</p>
        <div class="project-tags">
          ${projeto.tags.map(tag => `<span class="project-tag">${tag}</span>`).join('')}
        </div>
        <p style="font-size: 1.1rem; color: var(--text-sec); max-width: 600px; margin: 0 auto; line-height: 1.6;">
          ${projeto.desc}
        </p>
      </div>
    </section>

    <section class="project-section">
      <div class="container">
        <a href="/portfolio/${categoria}/" class="back-link">
          <i class="fas fa-arrow-left"></i>
          Voltar para ${categoria === 'botsdiscord' ? 'Bots Discord' : categoria === 'sites' ? 'Sites' : 'Automações'}
        </a>

        <div class="project-details">
          <div class="detail-card">
            <h3><i class="fas fa-info-circle"></i> Informações do Projeto</h3>
            <div class="detail-item">
              <span class="detail-label">Cliente</span>
              <span class="detail-value">${projeto.detalhes.cliente}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Duração</span>
              <span class="detail-value">${projeto.detalhes.duracao}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Status</span>
              <span class="detail-value">${projeto.detalhes.status}</span>
            </div>
          </div>

          <div class="detail-card">
            <h3><i class="fas fa-code"></i> Tecnologias Utilizadas</h3>
            <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-top: 16px;">
              ${projeto.detalhes.tecnologias.map(tech => `
                <span class="project-tag">${tech}</span>
              `).join('')}
            </div>
          </div>
        </div>

        <div class="detail-card">
          <h3><i class="fas fa-star"></i> Funcionalidades Implementadas</h3>
          <div class="features-grid">
            ${projeto.detalhes.funcionalidades.map(func => `
              <div class="feature-item">
                <div class="feature-icon">
                  <i class="fas fa-check"></i>
                </div>
                <div class="feature-text">
                  <h4>${func}</h4>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="result-box">
          <h3><i class="fas fa-trophy"></i> Resultados Alcançados</h3>
          <p>${projeto.detalhes.resultado}</p>
        </div>

        <div style="text-align: center; margin-top: 40px;">
          <a href="/contato/" class="btn btn-primary" style="margin-right: 12px;">
            <i class="fas fa-paper-plane"></i> Solicitar Projeto Similiar
          </a>
          <a href="/portfolio/" class="btn btn-secondary">
            <i class="fas fa-th"></i> Ver Todos os Projetos
          </a>
        </div>
      </div>
    </section>

    ${renderFooter(false)}
  `;

  // Atualiza metadados dinamicamente
  document.title = `Hive Dev - ${projeto.title} - Portfólio`;
  
  // Atualiza meta description
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc) metaDesc.content = projeto.desc;
  
  // Atualiza Open Graph
  const ogTitle = document.querySelector('meta[property="og:title"]');
  if (ogTitle) ogTitle.content = `Hive Dev - ${projeto.title}`;
  
  const ogDesc = document.querySelector('meta[property="og:description"]');
  if (ogDesc) ogDesc.content = projeto.desc;

})();
