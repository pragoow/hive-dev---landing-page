// Sitemap XML Generator
const fs = require('fs');
const path = require('path');

const pages = [
  { url: '/', priority: '1.0', changefreq: 'weekly' },
  { url: '/servicos/', priority: '0.8', changefreq: 'monthly' },
  { url: '/portfolio/', priority: '0.8', changefreq: 'weekly' },
  { url: '/contato/', priority: '0.9', changefreq: 'monthly' },
  { url: '/faq/', priority: '0.7', changefreq: 'monthly' },
  { url: '/termos/', priority: '0.5', changefreq: 'yearly' },
  { url: '/privacidade/', priority: '0.5', changefreq: 'yearly' },
  { url: '/404/', priority: '0.1', changefreq: 'yearly' }
];

const generateSitemap = () => {
  const baseUrl = 'https://hivedev.top';
  const currentDate = new Date().toISOString().split('T')[0];
  
  let sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n';
  sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  
  pages.forEach(page => {
    sitemap += '  <url>\n';
    sitemap += `    <loc>${baseUrl}${page.url}</loc>\n`;
    sitemap += `    <lastmod>${currentDate}</lastmod>\n`;
    sitemap += `    <priority>${page.priority}</priority>\n`;
    sitemap += `    <changefreq>${page.changefreq}</changefreq>\n`;
    sitemap += '  </url>\n';
  });
  
  sitemap += '</urlset>';
  
  fs.writeFileSync(path.join(__dirname, '..', '..', 'sitemap.xml'), sitemap);
  console.log('✅ Sitemap.xml generated successfully!');
};

// Generate sitemap
generateSitemap();

// Auto-generate when files change
if (require.main === module) {
  generateSitemap();
}

module.exports = { generateSitemap };
