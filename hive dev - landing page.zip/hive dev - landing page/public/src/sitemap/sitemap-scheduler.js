// Sitemap Scheduler - Gera sitemap a cada 3 dias
const { generateSitemap } = require('./sitemap-generator');
const fs = require('fs');
const path = require('path');

const SCHEDULE_FILE = path.join(__dirname, '.sitemap-schedule.json');
const INTERVAL_DAYS = 3; // Gerar a cada 3 dias

class SitemapScheduler {
  constructor() {
    this.scheduleFile = SCHEDULE_FILE;
    this.intervalDays = INTERVAL_DAYS;
  }

  // Lê a última data de geração
  getLastGeneration() {
    try {
      if (fs.existsSync(this.scheduleFile)) {
        const data = JSON.parse(fs.readFileSync(this.scheduleFile, 'utf8'));
        return new Date(data.lastGenerated);
      }
    } catch (error) {
      console.log('⚠️  Erro ao ler agendamento:', error.message);
    }
    return null;
  }

  // Salva a data de geração atual
  saveGeneration() {
    try {
      const data = {
        lastGenerated: new Date().toISOString(),
        nextGeneration: new Date(Date.now() + (this.intervalDays * 24 * 60 * 60 * 1000)).toISOString()
      };
      fs.writeFileSync(this.scheduleFile, JSON.stringify(data, null, 2));
      console.log('✅ Agendamento atualizado');
    } catch (error) {
      console.log('❌ Erro ao salvar agendamento:', error.message);
    }
  }

  // Verifica se precisa gerar sitemap
  shouldGenerate() {
    const lastGen = this.getLastGeneration();
    
    if (!lastGen) {
      console.log('📅 Primeira geração de sitemap');
      return true;
    }

    const now = new Date();
    const daysSinceLastGen = Math.floor((now - lastGen) / (1000 * 60 * 60 * 24));
    
    if (daysSinceLastGen >= this.intervalDays) {
      console.log(`📅 ${daysSinceLastGen} dias desde última geração. Gerando novo sitemap...`);
      return true;
    }

    const nextGen = new Date(lastGen.getTime() + (this.intervalDays * 24 * 60 * 60 * 1000));
    const daysUntilNext = Math.ceil((nextGen - now) / (1000 * 60 * 60 * 24));
    
    console.log(`⏰ Próxima geração em ${daysUntilNext} dias (${nextGen.toLocaleDateString('pt-BR')})`);
    return false;
  }

  // Gera sitemap se necessário
  async checkAndGenerate() {
    console.log('🔍 Verificando agendamento do sitemap...');
    
    if (this.shouldGenerate()) {
      try {
        console.log('🚀 Gerando sitemap agendado...');
        generateSitemap();
        this.saveGeneration();
        
        // Log do próximo agendamento
        const nextGen = new Date(Date.now() + (this.intervalDays * 24 * 60 * 60 * 1000));
        console.log(`📅 Próxima geração: ${nextGen.toLocaleDateString('pt-BR')} (${nextGen.toLocaleTimeString('pt-BR')})`);
        
      } catch (error) {
        console.log('❌ Erro ao gerar sitemap agendado:', error.message);
      }
    }
  }

  // Inicia agendador contínuo (opcional)
  startContinuous() {
    console.log('🔄 Iniciando agendador contínuo (verificação a cada hora)...');
    
    // Verificar a cada hora
    setInterval(() => {
      this.checkAndGenerate();
    }, 60 * 60 * 1000); // 1 hora
    
    // Verificação inicial
    this.checkAndGenerate();
  }

  // Força geração (reseta agendamento)
  forceGenerate() {
    console.log('🔧 Forçando geração do sitemap...');
    try {
      generateSitemap();
      this.saveGeneration();
      console.log('✅ Sitemap gerado com sucesso!');
    } catch (error) {
      console.log('❌ Erro ao forçar geração:', error.message);
    }
  }

  // Mostra status do agendamento
  showStatus() {
    const lastGen = this.getLastGeneration();
    
    console.log('\n📊 Status do Agendador de Sitemap:');
    console.log('=' .repeat(50));
    
    if (lastGen) {
      const now = new Date();
      const daysSinceLastGen = Math.floor((now - lastGen) / (1000 * 60 * 60 * 24));
      const nextGen = new Date(lastGen.getTime() + (this.intervalDays * 24 * 60 * 60 * 1000));
      const daysUntilNext = Math.ceil((nextGen - now) / (1000 * 60 * 60 * 24));
      
      console.log(`📅 Última geração: ${lastGen.toLocaleDateString('pt-BR')} (${lastGen.toLocaleTimeString('pt-BR')})`);
      console.log(`⏳ Dias desde última: ${daysSinceLastGen}`);
      console.log(`📅 Próxima geração: ${nextGen.toLocaleDateString('pt-BR')} (${nextGen.toLocaleTimeString('pt-BR')})`);
      console.log(`⏰ Dias até próxima: ${daysUntilNext}`);
    } else {
      console.log('❌ Nenhuma geração registrada');
    }
    
    console.log(`⚙️  Intervalo: ${this.intervalDays} dias`);
    console.log('=' .repeat(50));
  }
}

// Execução direta
if (require.main === module) {
  const scheduler = new SitemapScheduler();
  const command = process.argv[2];
  
  switch (command) {
    case 'continuous':
      scheduler.startContinuous();
      break;
    case 'force':
      scheduler.forceGenerate();
      break;
    case 'status':
      scheduler.showStatus();
      break;
    default:
      // Verificação única (padrão)
      scheduler.checkAndGenerate();
      break;
  }
}

module.exports = SitemapScheduler;
