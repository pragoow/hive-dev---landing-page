/**
 * HIVE DEV - SERVIÇOS PAGE
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  app.innerHTML = `
    ${renderNavbar('servicos')}

    <section class="hero" style="min-height: auto; padding: 140px 24px 60px;">
      <div class="hero-content">
        <span class="section-label">Nossos Serviços</span>
        <h1 style="font-size: clamp(2rem, 5vw, 3.5rem);">
          <span style="color: var(--accent);">Soluções</span> completas.
        </h1>
        <p style="margin-bottom: 0;">Cada projeto é único. Desenvolvemos do zero, sem templates, exclusivamente para você.</p>
      </div>
    </section>

    <section class="section" style="padding-top: 0;">
      <div class="cards-grid" style="grid-template-columns: 1fr; max-width: 900px;">
        <div class="card" style="display: grid; grid-template-columns: auto 1fr; gap: 32px; align-items: start;">
          <div class="card-icon" style="width: 80px; height: 80px; font-size: 2.5rem; flex-shrink: 0;">
            <i class="fab fa-discord"></i>
          </div>
          <div>
            <h3 style="font-size: 1.75rem; margin-bottom: 16px;">Bots Discord</h3>
            <p style="margin-bottom: 20px; font-size: 1.05rem;">Desenvolvemos bots completos com as funcionalidades mais modernas do Discord. Slash commands, botões, menus e modals para uma experiência premium.</p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 24px;">
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Moderação automática</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Sistema de níveis</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Economia & lojas</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Música & playlists</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Tickets & suporte</span>
            </div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 24px;">
              <span class="tag">Discord.js</span>
              <span class="tag">Node.js</span>
              <span class="tag">TypeScript</span>
              <span class="tag">MongoDB</span>
            </div>
            <a href="/contato/" class="btn btn-primary">Solicitar bot</a>
          </div>
        </div>

        <div class="card" style="display: grid; grid-template-columns: auto 1fr; gap: 32px; align-items: start;">
          <div class="card-icon" style="width: 80px; height: 80px; font-size: 2.5rem; flex-shrink: 0;">
            <i class="fas fa-globe"></i>
          </div>
          <div>
            <h3 style="font-size: 1.75rem; margin-bottom: 16px;">Sites & Web</h3>
            <p style="margin-bottom: 20px; font-size: 1.05rem;">Criamos sites profissionais, rápidos e responsivos. Design único sem templates, código limpo e otimizado para performance e SEO.</p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 24px;">
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Design responsivo</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Performance otimizada</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">SEO pronto</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Painel admin</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">E-commerces</span>
            </div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 24px;">
              <span class="tag">React</span>
              <span class="tag">Next.js</span>
              <span class="tag">Tailwind</span>
              <span class="tag">Node.js</span>
            </div>
            <a href="/portfolio/" class="btn btn-primary">Ver Portfólio</a>
          </div>
        </div>

        <div class="card" style="display: grid; grid-template-columns: auto 1fr; gap: 32px; align-items: start;">
          <div class="card-icon" style="width: 80px; height: 80px; font-size: 2.5rem; flex-shrink: 0;">
            <i class="fas fa-robot"></i>
          </div>
          <div>
            <h3 style="font-size: 1.75rem; margin-bottom: 16px;">Automações</h3>
            <p style="margin-bottom: 20px; font-size: 1.05rem;">Transforme tarefas manuais em processos automatizados. Economize horas de trabalho repetitivo com soluções inteligentes.</p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 24px;">
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Planilhas automáticas</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Web scraping</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Relatórios auto</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">Integração APIs</span>
              <span class="tag" style="background: rgba(0, 217, 255, 0.1); border-color: var(--accent); color: var(--accent);">WhatsApp/Telegram</span>
            </div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 24px;">
              <span class="tag">Python</span>
              <span class="tag">Selenium</span>
              <span class="tag">Puppeteer</span>
              <span class="tag">n8n</span>
            </div>
            <a href="/portfolio/" class="btn btn-primary">Ver Portfólio</a>
          </div>
        </div>
      </div>
    </section>

    <section class="section" style="background: var(--bg-sec); text-align: center;">
      <span class="section-label">Vamos começar</span>
      <h2 style="margin-bottom: 16px;">Pronto para começar?</h2>
      <p style="color: var(--text-sec); max-width: 500px; margin: 0 auto 32px;">Orçamento gratuito e sem compromisso. Escolha o serviço ideal para você.</p>
      <a href="/contato/" class="btn btn-primary" style="padding: 14px 32px; font-size: 1rem;">
        <i class="fas fa-paper-plane"></i> Solicitar orçamento
      </a>
    </section>

    ${renderFooter(false)}
  `;
})();
