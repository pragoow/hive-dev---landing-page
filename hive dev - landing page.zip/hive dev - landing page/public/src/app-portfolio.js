/**
 * HIVE DEV - PORTFOLIO PAGE
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  const projects = [
    {
      title: 'Moderação Pro',
      subtitle: 'Bot Discord',
      icon: 'fab fa-discord',
      gradient: 'linear-gradient(135deg, #5865F2, #4752C4)',
      tags: ['Discord.js', 'Node.js', 'MongoDB']
    },
    {
      title: 'Loja Virtual',
      subtitle: 'E-commerce',
      icon: 'fas fa-shopping-bag',
      gradient: 'linear-gradient(135deg, #3b82f6, #2563eb)',
      tags: ['Next.js', 'Stripe', 'Tailwind']
    },
    {
      title: 'Relatórios Auto',
      subtitle: 'Automação',
      icon: 'fas fa-robot',
      gradient: 'linear-gradient(135deg, #10b981, #059669)',
      tags: ['Python', 'Pandas', 'Selenium']
    },
    {
      title: 'Bot de Música',
      subtitle: 'Discord Bot',
      icon: 'fas fa-music',
      gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
      tags: ['Discord.js', 'Lavalink', 'Spotify']
    },
    {
      title: 'Site Corporativo',
      subtitle: 'Web Design',
      icon: 'fas fa-building',
      gradient: 'linear-gradient(135deg, #f59e0b, #d97706)',
      tags: ['React', 'Framer Motion', 'CMS']
    },
    {
      title: 'Sistema de Level',
      subtitle: 'Gamificação',
      icon: 'fas fa-trophy',
      gradient: 'linear-gradient(135deg, #ec4899, #db2777)',
      tags: ['Discord.js', 'Redis', 'Canvas']
    }
  ];

  app.innerHTML = `
    ${renderNavbar('portfolio')}

    <section class="hero" style="min-height: auto; padding: 140px 24px 60px;">
      <div class="hero-content">
        <span class="section-label">Portfólio</span>
        <h1 style="font-size: clamp(2rem, 5vw, 3.5rem);">
          <span style="color: var(--accent);">Trabalhos</span> entregues.
        </h1>
        <p style="margin-bottom: 0;">Projetos reais, desenvolvidos do zero para clientes exigentes.</p>
      </div>
    </section>

    <section class="section" style="padding-top: 0;">
      <div class="portfolio-grid" style="max-width: 1100px;">
        ${projects.map(p => `
          <div class="portfolio-card" style="cursor: pointer;">
            <div class="portfolio-visual" style="background: ${p.gradient}; height: 160px;">
              <i class="${p.icon}" style="font-size: 3.5rem; color: rgba(255,255,255,0.9);"></i>
            </div>
            <div class="portfolio-content">
              <div class="portfolio-header">
                <div class="portfolio-icon" style="background: ${p.gradient}; width: 44px; height: 44px;">
                  <i class="${p.icon}" style="font-size: 1.25rem; color: #fff;"></i>
                </div>
                <div>
                  <div class="portfolio-title" style="font-weight: 600;">${p.title}</div>
                  <div class="portfolio-subtitle">${p.subtitle}</div>
                </div>
              </div>
              <div class="portfolio-tags">
                ${p.tags.map(t => `<span class="tag">${t}</span>`).join('')}
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </section>

    <section class="section" style="background: var(--bg-sec);">
      <div style="text-align: center;">
        <span class="section-label">Resultados</span>
        <div style="display: flex; justify-content: center; gap: 64px; margin-top: 40px; flex-wrap: wrap;">
          <div style="text-align: center;">
            <div style="font-family: 'Space Grotesk', sans-serif; font-size: 3rem; font-weight: 700; color: var(--accent); line-height: 1;">50+</div>
            <div style="color: var(--text-sec); margin-top: 8px;">Projetos</div>
          </div>
          <div style="text-align: center;">
            <div style="font-family: 'Space Grotesk', sans-serif; font-size: 3rem; font-weight: 700; color: var(--accent); line-height: 1;">100%</div>
            <div style="color: var(--text-sec); margin-top: 8px;">Satisfeitos</div>
          </div>
          <div style="text-align: center;">
            <div style="font-family: 'Space Grotesk', sans-serif; font-size: 3rem; font-weight: 700; color: var(--accent); line-height: 1;">3+</div>
            <div style="color: var(--text-sec); margin-top: 8px;">Anos</div>
          </div>
        </div>
      </div>
    </section>

    <section class="section" style="text-align: center;">
      <span class="section-label">Vamos criar</span>
      <h2 style="margin-bottom: 16px;">Quer seu projeto aqui?</h2>
      <p style="color: var(--text-sec); max-width: 500px; margin: 0 auto 32px;">Vamos criar algo incrível juntos. Orçamento gratuito e sem compromisso.</p>
      <a href="/contato/" class="btn btn-primary" style="padding: 14px 32px; font-size: 1rem;">
        <i class="fas fa-paper-plane"></i> Iniciar projeto
      </a>
    </section>

    ${renderFooter(false)}
  `;
})();
