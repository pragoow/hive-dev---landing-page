/**
 * HIVE DEV - HOME
 * Versão otimizada com performance e SEO melhorados
 */

(function() {
  'use strict';

  const { renderNavbar, renderFooter } = window.HiveDesign;

  const app = document.getElementById('app');
  if (!app) return;

  // Performance: Preload critical resources
  const preloadCriticalResources = () => {
    const criticalFonts = [
      'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap'
    ];
    
    criticalFonts.forEach(font => {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'style';
      link.href = font;
      link.onload = function() { this.rel = 'stylesheet'; };
      document.head.appendChild(link);
    });
  };

  // SEO: Adicionar structured data dinâmico
  const addStructuredData = () => {
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Hive Dev",
      "url": "https://hivedev.com",
      "logo": "https://hivedev.com/public/assets/hive dev - logo branca.png",
      "description": "Desenvolvimento profissional de bots, sites e automações sob medida",
      "sameAs": [
        "https://discord.gg/hivedev",
        "https://instagram.com/hivedevofc"
      ],
      "services": [
        "Desenvolvimento de Sites",
        "Bots Discord", 
        "Automações",
        "Sistemas Web"
      ]
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);
  };

  // Performance: Lazy loading para imagens
  const setupLazyLoading = () => {
    if ('IntersectionObserver' in window) {
      const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target;
            if (img.dataset.src) {
              img.src = img.dataset.src;
              img.classList.remove('lazy');
              imageObserver.unobserve(img);
            }
          }
        });
      });

      document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
      });
    }
  };

  // Performance: Medir tempo de carregamento
  const measurePerformance = () => {
    if ('performance' in window) {
      window.addEventListener('load', () => {
        const perfData = performance.getEntriesByType('navigation')[0];
        const loadTime = perfData.loadEventEnd - perfData.loadEventStart;
        console.log(`Page load time: ${loadTime}ms`);
      });
    }
  };

  // Inicializar otimizações
  preloadCriticalResources();
  addStructuredData();
  measurePerformance();

  // PWA: Registrar service worker
  const isLocalhost = ['localhost', '127.0.0.1'].includes(window.location.hostname);

  if ('serviceWorker' in navigator) {
    if (isLocalhost) {
      // Dev safety: remove any existing SW/caches so dev never gets stuck with stale assets
      window.addEventListener('load', async () => {
        try {
          const regs = await navigator.serviceWorker.getRegistrations();
          await Promise.all(regs.map((r) => r.unregister()));

          if ('caches' in window) {
            const keys = await caches.keys();
            await Promise.all(keys.map((k) => caches.delete(k)));
          }
        } catch (error) {
          console.error('[SW] Dev cleanup failed:', error);
        }
      });
    } else {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/public/sw.js')
          .then(registration => {
            console.log('[SW] Service Worker registered:', registration);

            // Verificar por atualizações
            registration.addEventListener('updatefound', () => {
              const newWorker = registration.installing;
              if (newWorker) {
                newWorker.addEventListener('statechange', () => {
                  if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                    // Nova versão disponível
                    if (confirm('Nova versão disponível! Deseja atualizar?')) {
                      window.location.reload();
                    }
                  }
                });
              }
            });
          })
          .catch(error => {
            console.error('[SW] Service Worker registration failed:', error);
          });
      });
    }
  }

  // CSS minimalista consistente com design-system
  const HOME_STYLES = `
    /* Garantir que navbar tenha mesmo tamanho em todas as páginas */
    .nav {
      width: 900px !important;
      max-width: calc(100vw - 32px) !important;
      height: 60px !important;
      padding: 0 20px !important;
    }

    .home-hero {
      min-height: 100vh;
      min-height: 100dvh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 100px 24px 60px;
      text-align: center;
    }

    .home-hero .container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .hero-content {
      max-width: 700px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .hero-content h1 {
      font-size: clamp(2.5rem, 5vw, 4rem);
      margin-bottom: 20px;
      line-height: 1.1;
    }

    .hero-content p {
      font-size: 1.1rem;
      color: var(--text-sec);
      margin-bottom: 30px;
      max-width: 500px;
      margin-left: auto;
      margin-right: auto;
    }

    .hero-cta {
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
      justify-content: center;
    }

    .build-section {
      padding: 80px 24px;
      background: var(--bg-sec);
    }

    .build-section .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .section-title {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .section-subtitle {
      color: var(--text-sec);
      margin-bottom: 40px;
    }

    .build-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px;
    }

    .build-card-link:nth-child(3) {
      grid-column: span 2;
      max-width: 600px;
      margin: 0 auto;
      width: 100%;
    }

    .build-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 24px;
      height: 100%;
      display: flex;
      flex-direction: column;
    }

    .build-card p {
      margin-top: auto;
    }

    .build-card-link {
      text-decoration: none;
      color: inherit;
      display: block;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      overflow: hidden;
      border-radius: 16px;
    }

    .build-card-link:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0, 217, 255, 0.1);
    }

    .build-card-link:hover .build-card {
      border-color: rgba(0, 217, 255, 0.3);
    }

    .build-card-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 16px;
      font-weight: 600;
    }

    .build-card-title {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .build-card-header i {
      color: var(--accent);
    }

    .build-status {
      font-size: 0.7rem;
      color: var(--accent);
      border: 1px solid rgba(0,217,255,0.3);
      padding: 4px 10px;
      border-radius: 999px;
      background: rgba(0,217,255,0.1);
    }

    .code-preview {
      background: rgba(0,0,0,0.25);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 16px;
      overflow: hidden;
    }

    .code-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
      padding-bottom: 12px;
      border-bottom: 1px solid var(--border);
    }

    .code-dots {
      display: flex;
      gap: 6px;
    }

    .code-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }

    .code-dot:nth-child(1) { background: #ff5f56; }
    .code-dot:nth-child(2) { background: #ffbd2e; }
    .code-dot:nth-child(3) { background: #27c93f; }

    .code-status {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 0.7rem;
      font-weight: 600;
      color: #27c93f;
      border: 1px solid rgba(39, 201, 63, 0.3);
      padding: 4px 10px;
      border-radius: 999px;
      background: rgba(39, 201, 63, 0.1);
    }

    .code-status::before {
      content: '';
      width: 6px;
      height: 6px;
      background: #27c93f;
      border-radius: 50%;
    }

    .code-filename {
      font-family: monospace;
      font-size: 0.75rem;
      color: var(--text-ter);
      margin-left: 12px;
    }

    .code-header-left {
      display: flex;
      align-items: center;
    }

    .code-block {
      font-family: ui-monospace, SFMono-Regular, monospace;
      font-size: 0.85rem;
      line-height: 1.7;
      color: rgba(255,255,255,0.85);
    }

    .code-block .comment { color: rgba(255,255,255,0.5); }
    .code-block .string { color: var(--accent); }

    .site-mockup {
      background: rgba(0,0,0,0.25);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 16px;
      overflow: hidden;
    }

    .mockup-browser {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 1px solid var(--border);
    }

    .mockup-dots {
      display: flex;
      gap: 6px;
    }

    .mockup-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--border);
    }

    .mockup-url {
      flex: 1;
      background: rgba(255,255,255,0.05);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 6px 12px;
      font-size: 0.75rem;
      color: var(--text-ter);
      text-align: center;
    }

    .mockup-content {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .mockup-bar {
      height: 8px;
      background: rgba(0,217,255,0.3);
      border-radius: 4px;
      width: 40%;
    }

    .mockup-line {
      height: 6px;
      background: rgba(255,255,255,0.1);
      border-radius: 3px;
    }

    .mockup-line.short { width: 70%; }
    .mockup-line.shorter { width: 50%; }

    .mockup-cards {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      margin-top: 8px;
    }

    .mockup-card {
      height: 40px;
      background: rgba(255,255,255,0.08);
      border-radius: 6px;
    }

    .mockup-btn {
      height: 24px;
      width: 80px;
      background: rgba(0,217,255,0.25);
      border-radius: 6px;
      margin-top: 8px;
    }

    .workflow-preview {
      background: rgba(0,0,0,0.2);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 24px;
      margin-bottom: 16px;
    }

    .workflow-steps {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
    }

    .workflow-step {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
    }

    .workflow-box {
      width: 60px;
      height: 60px;
      border: 1px solid var(--border);
      border-radius: 12px;
      background: rgba(255,255,255,0.02);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .workflow-box.accent {
      border-color: rgba(0,217,255,0.4);
      background: rgba(0,217,255,0.08);
    }

    .workflow-box i {
      font-size: 1.2rem;
      color: var(--text-sec);
    }

    .workflow-box.accent i {
      color: var(--accent);
    }

    .workflow-label {
      font-size: 0.7rem;
      color: var(--text-ter);
      font-family: monospace;
    }

    .workflow-arrow {
      color: var(--text-ter);
      font-size: 0.9rem;
    }

    .build-card p {
      color: var(--text-sec);
      font-size: 0.9rem;
      line-height: 1.6;
    }

    .steps-section {
      padding: 80px 24px;
    }

    .steps-section .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .steps-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
    }

    .step-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 24px;
    }

    .step-number {
      width: 36px;
      height: 36px;
      border-radius: 10px;
      background: rgba(0,217,255,0.1);
      border: 1px solid rgba(0,217,255,0.2);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      margin-bottom: 15px;
    }

    .step-card h3 {
      font-size: 1rem;
      margin-bottom: 8px;
    }

    .step-card p {
      color: var(--text-sec);
      font-size: 0.9rem;
      line-height: 1.6;
    }

    .cta-section {
      padding: 60px 24px;
    }

    .cta-box {
      max-width: 1200px;
      margin: 0 auto;
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 30px;
    }

    .cta-content h2 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .cta-content p {
      color: var(--text-sec);
    }

    @media (max-width: 900px) {
      .build-grid { grid-template-columns: 1fr; }
      .steps-grid { grid-template-columns: repeat(2, 1fr); }
      .cta-box { flex-direction: column; text-align: center; }
    }

    @media (max-width: 600px) {
      .steps-grid { grid-template-columns: 1fr; }
    }

    /* Animações rápidas e elegantes */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .build-card {
      opacity: 0;
      animation: fadeInUp 0.3s ease-out forwards;
    }

    .build-card:nth-child(1) { animation-delay: 0.05s; }
    .build-card:nth-child(2) { animation-delay: 0.1s; }
    .build-card:nth-child(3) { animation-delay: 0.15s; }

    .step-card {
      opacity: 0;
      transform: translateY(10px);
      transition: opacity 0.25s ease-out, transform 0.25s ease-out;
    }

    .step-card.in-view {
      opacity: 1;
      transform: translateY(0);
      transition: opacity 0.4s ease-out, transform 0.4s ease-out;
    }

    .step-card:nth-child(1).in-view { transition-delay: 0.05s; }
    .step-card:nth-child(2).in-view { transition-delay: 0.1s; }
    .step-card:nth-child(3).in-view { transition-delay: 0.15s; }
    .step-card:nth-child(4).in-view { transition-delay: 0.2s; }
  `;

  const style = document.createElement('style');
  style.textContent = HOME_STYLES;
  document.head.appendChild(style);

  const builds = [
    {
      icon: 'fab fa-discord',
      title: 'Bots Discord',
      status: 'ONLINE',
      type: 'code',
      filename: 'bot.js',
      preview: '<span class="comment">// bot.js</span>\nclient.on(<span class="string">"ready"</span>, () => {\n  console.log(<span class="string">"Online"</span>)\n})',
      desc: 'Moderação, economia, tickets, verificação. Cada bot é escrito do zero pra sua comunidade.'
    },
    {
      icon: 'fas fa-robot',
      title: 'Automações',
      status: 'WORKFLOWS',
      type: 'workflow',
      desc: 'Integrações entre plataformas, scraping, webhooks e workflows sob medida.'
    },
    {
      icon: 'fas fa-globe',
      title: 'Sites',
      status: 'RÁPIDO',
      type: 'mockup',
      url: 'seusite.com.br',
      desc: 'Landing pages, dashboards e sistemas completos. Rápido e responsivo.'
    }
  ];

  const steps = [
    {
      title: 'Fale com a gente',
      desc: 'Conta o que você precisa pelo Discord/Instagram. Respondemos em até 24h.'
    },
    {
      title: 'Planejamento',
      desc: 'Escopo e prazo claros. Sem promessas irreais e sem burocracia.'
    },
    {
      title: 'Desenvolvemos',
      desc: 'Criamos tudo do zero. Você acompanha cada etapa com transparência.'
    },
    {
      title: 'Entrega + garantia',
      desc: 'Entrega funcional + garantia. Evolução e manutenção quando precisar.'
    }
  ];

  app.innerHTML = `
    ${renderNavbar('home')}

    <section class="home-hero">
      <div class="container">
        <div class="hero-content">
          <span class="badge"><i class="fas fa-code"></i> Desenvolvimento sob medida</span>
          <h1>Criamos seu <span style="color: var(--accent);">projeto</span>.</h1>
          <p>Sem templates, sem reuso. Código escrito do zero, pra você. Interface minimalista, performance e acabamento profissional.</p>
          <div style="display: flex; gap: 12px; flex-wrap: wrap;">
            <a href="/contato/" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Pedir orçamento</a>
            <a href="/servicos/" class="btn btn-secondary"><i class="fas fa-list-check"></i> Ver serviços</a>
          </div>
        </div>
      </div>
    </section>

    <section class="build-section">
      <div class="container">
        <h2 class="section-title">O que construímos.</h2>
        <p class="section-subtitle">Bots, sites e automações com entrega direta e padrão profissional.</p>
        
        <div class="build-grid">
          ${builds.map(b => `
            <a href="/servicos/" class="build-card-link">
              <div class="build-card">
                <div class="build-card-header">
                  <div class="build-card-title">
                    <i class="${b.icon}"></i>
                    <span>${b.title}</span>
                  </div>
                  <span class="build-status">${b.status}</span>
                </div>
              ${b.type === 'mockup' ? `
              <div class="site-mockup">
                <div class="mockup-browser">
                  <div class="mockup-dots">
                    <span class="mockup-dot"></span>
                    <span class="mockup-dot"></span>
                    <span class="mockup-dot"></span>
                  </div>
                  <div class="mockup-url">${b.url}</div>
                </div>
                <div class="mockup-content">
                  <div class="mockup-bar"></div>
                  <div class="mockup-line"></div>
                  <div class="mockup-line short"></div>
                  <div class="mockup-cards">
                    <div class="mockup-card"></div>
                    <div class="mockup-card"></div>
                    <div class="mockup-card"></div>
                  </div>
                  <div class="mockup-btn"></div>
                </div>
              </div>
              ` : b.type === 'workflow' ? `
              <div class="workflow-preview">
                <div class="workflow-steps">
                  <div class="workflow-step">
                    <div class="workflow-box">API</div>
                    <span class="workflow-label">trigger</span>
                  </div>
                  <i class="fas fa-chevron-right workflow-arrow"></i>
                  <div class="workflow-step">
                    <div class="workflow-box accent"><i class="fas fa-heart-pulse"></i></div>
                    <span class="workflow-label">process</span>
                  </div>
                  <i class="fas fa-chevron-right workflow-arrow"></i>
                  <div class="workflow-step">
                    <div class="workflow-box"><i class="fas fa-check"></i></div>
                    <span class="workflow-label">output</span>
                  </div>
                  <i class="fas fa-chevron-right workflow-arrow"></i>
                  <div class="workflow-step">
                    <div class="workflow-box"><i class="fas fa-clock"></i></div>
                    <span class="workflow-label">cron</span>
                  </div>
                </div>
              </div>
              ` : `
              <div class="code-preview">
                <div class="code-header">
                  <div class="code-header-left">
                    <div class="code-dots">
                      <span class="code-dot"></span>
                      <span class="code-dot"></span>
                      <span class="code-dot"></span>
                    </div>
                    <span class="code-filename">${b.filename}</span>
                  </div>
                  ${b.status === 'ONLINE' ? '<span class="code-status">ONLINE</span>' : ''}
                </div>
                <div class="code-block">${b.preview}</div>
              </div>
              `}
              <p>${b.desc}</p>
            </div>
          </a>
          `).join('')}
        </div>
      </div>
    </section>

    <section class="steps-section">
      <div class="container">
        <h2 class="section-title" style="margin-bottom: 40px;">Do primeiro contato à entrega.</h2>
        <div class="steps-grid">
          ${steps.map((s, i) => `
            <div class="step-card">
              <div class="step-number">${i + 1}</div>
              <h3>${s.title}</h3>
              <p>${s.desc}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </section>

    <section class="cta-section">
      <div class="cta-box">
        <div class="cta-content">
          <h2>Seu projeto merece ser único.</h2>
          <p>Descreva sua ideia e receba um orçamento personalizado. Sem compromisso.</p>
        </div>
        <div style="display: flex; gap: 12px;">
          <a href="/contato/" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Pedir orçamento</a>
          <a href="/servicos/" class="btn btn-secondary">Ver serviços</a>
        </div>
      </div>
    </section>

    ${renderFooter(true)}
  `;

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const stepCards = document.querySelectorAll('.steps-section .step-card');
  console.log('Step cards found:', stepCards.length);
  
  if (stepCards.length) {
    if (prefersReducedMotion) {
      stepCards.forEach((el) => el.classList.add('in-view'));
    } else {
      // Fallback: animar após um pequeno delay se IntersectionObserver não funcionar
      const fallbackTimeout = setTimeout(() => {
        stepCards.forEach((el) => {
          if (!el.classList.contains('in-view')) {
            el.classList.add('in-view');
          }
        });
      }, 1000);

      const stepObserver = new IntersectionObserver((entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            clearTimeout(fallbackTimeout);
            entry.target.classList.add('in-view');
            obs.unobserve(entry.target);
          }
        });
      }, { threshold: 0.2 });

      stepCards.forEach((el) => stepObserver.observe(el));
    }
  }
  
  // Inicializar lazy loading após renderizar
  setTimeout(setupLazyLoading, 100);
})();
