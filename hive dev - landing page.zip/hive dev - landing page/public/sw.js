/**
 * HIVE DEV - SERVICE WORKER
 * Cache strategy para performance e offline support
 */

const CACHE_NAME = 'hivedev-v1.0.0';
const STATIC_CACHE = 'hivedev-static-v1.0.0';
const DYNAMIC_CACHE = 'hivedev-dynamic-v1.0.0';

// Recursos críticos para cache
const STATIC_ASSETS = [
  '/',
  '/public/src/design-system.js',
  '/public/src/app.js',
  '/public/src/theme-preload.css',
  '/public/assets/hive dev - logo azul.png',
  '/public/assets/hive dev - logo branca.png',
  'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
];

// Instalação - cache de recursos estáticos
self.addEventListener('install', event => {
  console.log('[SW] Installing service worker...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then(cache => {
        console.log('[SW] Caching static assets');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => self.skipWaiting())
  );
});

// Ativação - limpar caches antigos
self.addEventListener('activate', event => {
  console.log('[SW] Activating service worker...');
  
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => self.clients.claim())
  );
});

// Estratégia de cache: Stale-While-Revalidate para performance
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Ignorar requisições de API e non-GET
  if (request.method !== 'GET' || url.protocol === 'chrome-extension:') {
    return;
  }
  
  // Estratégia para recursos estáticos
  if (STATIC_ASSETS.some(asset => request.url.includes(asset))) {
    event.respondWith(
      caches.match(request)
        .then(response => {
          if (response) {
            // Retornar do cache e atualizar em background
            fetch(request).then(fetchResponse => {
              caches.open(STATIC_CACHE).then(cache => {
                cache.put(request, fetchResponse.clone());
              });
            });
            return response;
          }
          // Se não está no cache, buscar e cache
          return fetch(request).then(fetchResponse => {
            caches.open(STATIC_CACHE).then(cache => {
              cache.put(request, fetchResponse.clone());
            });
            return fetchResponse;
          });
        })
    );
    return;
  }
  
  // Estratégia para páginas dinâmicas
  if (url.pathname.startsWith('/portfolio/') || 
      url.pathname.startsWith('/servicos/') || 
      url.pathname.startsWith('/contato/') || 
      url.pathname.startsWith('/faq/') || 
      url.pathname.startsWith('/termos/') || 
      url.pathname.startsWith('/privacidade/') || 
      url.pathname.startsWith('/404/')) {
    event.respondWith(
      caches.match(request)
        .then(response => {
          if (response) {
            return response;
          }
          return fetch(request).then(fetchResponse => {
            // Cache de páginas dinâmicas por 1 hora
            caches.open(DYNAMIC_CACHE).then(cache => {
              cache.put(request, fetchResponse.clone());
            });
            return fetchResponse;
          });
        })
    );
    return;
  }
  
  // Para outros recursos, tentar cache primeiro
  event.respondWith(
    caches.match(request)
      .then(response => {
        return response || fetch(request);
      })
  );
});

// Background sync para quando voltar online
self.addEventListener('sync', event => {
  if (event.tag === 'background-sync') {
    console.log('[SW] Background sync triggered');
    // Implementar lógica de sync se necessário
  }
});

// Push notifications (se necessário no futuro)
self.addEventListener('push', event => {
  console.log('[SW] Push received:', event);
  
  const options = {
    body: 'Novidades da Hive Dev!',
    icon: '/public/assets/hive dev - logo azul.png',
    badge: '/public/assets/hive dev - logo azul.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Ver Novidades',
        icon: '/public/assets/hive dev - logo azul.png'
      },
      {
        action: 'close',
        title: 'Fechar',
        icon: '/public/assets/hive dev - logo azul.png'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('Hive Dev', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
  console.log('[SW] Notification click received');
  
  event.notification.close();
  
  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Performance: Reportar métricas
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'PERFORMANCE_METRICS') {
    console.log('[SW] Performance metrics:', event.data.metrics);
    // Enviar para analytics se necessário
  }
});
